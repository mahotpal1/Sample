from openpyxl import Workbook
from openpyxl.styles import Font, Border, Side
import logging
import os
import xlsxwriter
from openpyxl.drawing.image import Image
from PIL import Image as PILImage
import openpyxl
from visualizers import graph_creator 
import shutil

class ExcelExporter:
    def __init__(self, logger, reportDir, folder, consumptionData):
        self.logger = logger
        self.reportDir = reportDir
        self.folder = folder
        self.consumptionData = consumptionData
        self.workBook = ''
        self.cols = 2 
        self.logger.info('ExcelExporter initialized.')
        self.threshold_worst_fmt = None
        self.threshold_ok_fmt = None

    def setFormat(self):
        self.threshold_worst_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "red",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )
        self.threshold_ok_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "yellow",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )

    def addGraphToSheet(self, workBookPath, workSheetName, spacing=20, cpuSheetName="CPU Utilization", romSheetName="ROM_Utilization", ramSheetName="RAM_Utilization"):
        folderPath = os.path.dirname(workBookPath)
        # Add cpu graph in utilization sheet.
        graph_path = os.path.join(folderPath, "cpu_core_wise_graph.png")
        if os.path.exists(graph_path):
            # Load workbook and sheet
            workbook = openpyxl.load_workbook(workBookPath)
            excel_img = Image(graph_path)
            # -------- Scale Image by 50% (no new file needed) --------
            excel_img.width = excel_img.width * 0.5
            excel_img.height = excel_img.height * 0.5
            sheet = workbook[cpuSheetName]
            sheet.add_image(excel_img, 'B2')
            workbook.save(workBookPath)
            self.logger.info("Graph placed at top of CPU sheet.")
        else:
            self.logger.warning("cpu_core_wise_graph.png not found, skipping graph insert.")
        # Add cpu graph in utilization sheet.
        graph_path = os.path.join(folderPath, "rom_util.png")
        if os.path.exists(graph_path):
            # Load workbook and sheet
            workbook = openpyxl.load_workbook(workBookPath)
            excel_img = Image(graph_path)
            # -------- Scale Image by 50% (no new file needed) --------
            excel_img.width = excel_img.width * 0.5
            excel_img.height = excel_img.height * 0.5
            sheet = workbook[romSheetName]
            sheet.add_image(excel_img, 'B2')
            workbook.save(workBookPath)
            self.logger.info("Graph placed at top of ROM sheet.")
        else:
            self.logger.warning("rom_util.png not found, skipping graph insert.")
        # Add RAM graph in utilization sheet.
        graph_path = os.path.join(folderPath, "ram_util.png")
        if os.path.exists(graph_path):
            # Load workbook and sheet
            workbook = openpyxl.load_workbook(workBookPath)
            excel_img = Image(graph_path)
            # -------- Scale Image by 50% (no new file needed) --------
            excel_img.width = excel_img.width * 0.5
            excel_img.height = excel_img.height * 0.5
            sheet = workbook[ramSheetName]
            sheet.add_image(excel_img, 'B2')
            workbook.save(workBookPath)
            self.logger.info("Graph placed at top of RAM sheet.")
        else:
            self.logger.warning("ram_util.png not found, skipping graph insert.")
        try:
            png_files = [f for f in os.listdir(folderPath) if f.endswith('.png')]
            if not png_files:
                self.logger.warning("No PNG files found in folder.")
                return
            images = []
            all_img_path = []
            for f in png_files:
                path = os.path.join(folderPath, f)
                all_img_path.append(path)
                try:
                    img = PILImage.open(path)
                    images.append(img)
                except Exception as e:
                    self.logger.warning(f"Failed to open {path}: {e}")
            if not images:
                self.logger.warning("No images could be opened.")
                return
            # --- Horizontal merge ---
            widths = [img.width for img in images]
            heights = [img.height for img in images]
            merged_width = sum(widths) + spacing * (len(images) - 1)
            merged_height = max(heights)
            merged_img = PILImage.new('RGB', (merged_width, merged_height), color=(255,255,255))
            x_offset = 0
            for img in images:
                merged_img.paste(img, (x_offset, 0))
                x_offset += img.width + spacing
            # Save temporary merged image
            merged_path = os.path.join(folderPath, "merged_graph.png")
            merged_img.save(merged_path)
            # Load workbook and sheet
            workbook = openpyxl.load_workbook(workBookPath)
            try:
                sheet = workbook[workSheetName]
            except KeyError:
                self.logger.warning(f"Sheet '{workSheetName}' not found.")
                return
            # Add merged image to sheet at C13
            excel_img = Image(merged_path)
            sheet.add_image(excel_img, 'C13')
            workbook.save(workBookPath)
            all_img_path.append(merged_path)
            try:
                for image_path in all_img_path:
                    os.remove(image_path)
                    self.logger.info(f"deleting file {image_path}")
            except Exception as E:
                self.logger.warning(f"Error occured while deleting file {E}")
            self.logger.info(f"Merged image added to sheet '{workSheetName}' successfully.")
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")

    def createWorkBook(self):
        try:
            # Create the folder structure
            folderPath = os.path.join(self.reportDir, self.folder)
            print(f"Creating Excel [{self.folder}]")
            if not os.path.exists(folderPath):
                os.makedirs(folderPath)
                flag = True
                self.logger.info(f"Folder created: {folderPath}")
            else:
                self.logger.info(f"Folder already exists: {folderPath}")
                try:
                    shutil.rmtree(folderPath) 
                    os.makedirs(folderPath) #Recreate the folder
                    self.logger.info(f"Folder deleted and recreated: {folderPath}")
                except OSError as e:
                    self.logger.error(f"Error deleting folder {folderPath}: {e}")
            # Create a workBook inside the folder
            workBookPath = os.path.abspath(os.path.join(folderPath, f"{self.folder}.xlsx"))
            workBook = xlsxwriter.Workbook(workBookPath)
            self.logger.info(f"WorkBook created: {workBookPath}")
        except OSError as e:
            self.logger.error(f"Error creating folder or workBook: {e}")
            print(f"Error creating folder or workBook: {e}")
        except Exception as e:
            self.logger.error(f"An unexpected error occurred: {e}")
            print(f"An unexpected error occurred: {e}")
        return workBook, workBookPath

    def labelFormat(self, row, column, borderSize, borderColor, workSheet):
        # Set the border format
        borderFormat = self.workBook.add_format({
            'border': borderSize,
            'border_color': borderColor
        })
        # Create a rowXcolumn grid with borders, 
        for row in range(row):
            for col in range(column):
                workSheet.write(row, col, '', borderFormat)

    def fontFormat(self, borderSize, borderColor, workSheet, fontSize, bold, bgColor='#FFFFFF'):
        # Set the border format
        font_format = self.workBook.add_format({
            'border': borderSize, 
            'font_size': fontSize,
            'bold': bold,
            'bg_color': bgColor
        })
        font_format.set_left_color(borderColor)
        font_format.set_right_color(borderColor)
        font_format.set_top_color(borderColor)
        font_format.set_bottom_color(borderColor)
        return font_format

    def createDefaultSheets(self):
        # Frontpage
        workSheet = self.workBook.add_worksheet('FrontPage')
        self.labelFormat(50, 50, 1, '#FFFFFF', workSheet)
        font_format = self.fontFormat(1,  '#FFFFFF', workSheet, 18, True)
        format_header = self.fontFormat(1,  '#FFFFFF', workSheet, 11, True, '#00FF00') 
        workSheet.write(3, 3, f'Integration Test Report', font_format)
        workSheet.set_column(2, 2, 20)
        workSheet.set_column(3, 3, 40)
        workSheet.set_row(3, 25)
        format_grey = self.workBook.add_format({
            'bg_color': '#CCCCCC',  # Grey background color
            'bold': True
        })
        format_green = self.workBook.add_format({
            'bg_color': '#00FF00'  # Green background color
        })
        data = [
            ["Report Type", "PerformanceTest_AppName"],
            ["Application Name", "AppName"],
            ["Version", "1.0.0"]
        ]
        # Write the data to the worksheet starting from cell C7
        for i, row in enumerate(data):
            workSheet.write(6 + i, 2, row[0], format_grey)
            workSheet.write(6 + i, 3, row[1], format_green)

    def fillCpuData(self, cpuData, workSheet, threshold, thresholdValue):
        sets = cpuData.keys()
        # cores = list(cpuData[list(cpuData.keys())[0]]['max_utilization'].keys())
        cores = list(cpuData['Summary']['max_utilization'].keys())
        num_sets = len(sets)
        num_cores = len(cores)
        header_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "#D9E1F2",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )
        title_fmt = self.workBook.add_format(
            {"bold": True, "align": "center", "valign": "vcenter", "border": 2}
        )
        value_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        value_summary_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        # Make the columns a bit wider for readability
        workSheet.set_column(0, self.cols + (len(cores) * 3) - 1, 12)
        workSheet.merge_range(2, self.cols, 2, self.cols+(num_cores*3)-1, 'CPU Idle (%)', header_fmt)
        # Write headers
        row = 3
        col = self.cols
        for i in range(len(cores)):
            workSheet.merge_range(row, col, row, col+2, cores[i], header_fmt)
            workSheet.write(row+1, col, "Maximum", header_fmt)
            workSheet.write(row+1, col+1, "Minimum", header_fmt)
            workSheet.write(row+1, col+2, "Average", header_fmt)
            col+=3

        # Write data for each set
        start_row = row+2  # Start writing data from row 2
        for set_name in sets:
            row = start_row
            workSheet.write(row, 1, set_name, title_fmt)
            for i in range(num_cores):
                max_val = cpuData[set_name]['max_utilization'][cores[i]]
                min_val = cpuData[set_name]['min_utilization'][cores[i]]
                avg_val = cpuData[set_name]['avg_utilization'][cores[i]]
                if set_name=='Summary':
                    workSheet.write_number(row, i * 3 + self.cols, max_val, value_summary_fmt)
                    workSheet.write_number(row, i * 3 + self.cols+1, min_val, value_summary_fmt)
                    workSheet.write_number(row, i * 3 + self.cols+2, avg_val, value_summary_fmt)
            start_row += 1  # Move to the next row for the next set
        workSheet.write(start_row, self.cols-1, "Threshold", title_fmt)
        workSheet.write(start_row, self.cols, thresholdValue, title_fmt)
        if threshold=='FAIL':
            workSheet.write(start_row+1, self.cols, threshold, self.threshold_worst_fmt)
        else:
            workSheet.write(start_row+1, self.cols, threshold, self.threshold_ok_fmt)
        workSheet.merge_range(start_row+3, self.cols, start_row+3, self.cols+6, "Note: ")
        workSheet.merge_range(start_row+4, self.cols, start_row+4, self.cols+6, "1. The above calculation of average is based on all the data points (total number of iterations)")
        workSheet.merge_range(start_row+5, self.cols, start_row+5, self.cols+6, "2. Pass/fail depends on consumption compared to a fixed threshold value in performanceConfig.json.")
        self.cols = 2+(3*len(cores))

    ##################################################
    # Cpu Result Sheet
    ##################################################
    def fillCpuSheet(self, cpuDetails, fileLink, sheetName="CPU Utilization"):
        """
        Fill CPU details into an Excel sheet using xlsxwriter.
        First 5 rows are left empty.
        Serial number in first column starting from row 6.
        Timestamp in second column.
        CPU utilization values appended with '%' and serial column colored blue.
        """
        try:
            ws = self.workBook.add_worksheet(sheetName)
            # Define formats
            header_format = self.workBook.add_format({
                'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': '#D9E1F2', 'border': 1
            })
            cell_format = self.workBook.add_format({'align': 'center', 'valign': 'vcenter', 'border': 1})
            serial_format = self.workBook.add_format({
                'align': 'center', 'valign': 'vcenter', 'border': 1, 'bg_color': '#BDD7EE'
            })
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory of the current script
            relative_path = os.path.relpath(fileLink, current_dir)
            ws.write(18, 1, "Result File Link")
            ws.write(18, 2, relative_path)
            # Header (row 5, index 4)
            header_row_idx = 21
            header = ["S.No", "Timestamp"]
            if cpuDetails:
                cores = list(list(cpuDetails.values())[0][0].keys())
                header.extend(cores)
                header.append("Top CPU Usage")
            for col_idx, col_name in enumerate(header):
                ws.write(header_row_idx, col_idx, col_name, header_format)
                ws.set_column(col_idx, col_idx, len(col_name)+4)  # set width
            # Fill data starting from row 6 (index 5)
            for row_idx, (timestamp, [cpu_dict, top_cpu]) in enumerate(cpuDetails.items(), start=1):
                excel_row = header_row_idx + row_idx  # actual Excel row index
                # Serial number in first column
                ws.write(excel_row, 0, row_idx, serial_format)
                # Timestamp in second column
                ws.write(excel_row, 1, timestamp, cell_format)
                # Write CPU cores with %
                for col_idx, core in enumerate(cores, start=2):
                    val = round(cpu_dict.get(core, 0.0), 2)
                    ws.write(excel_row, col_idx, f"{val}%", cell_format)
                # Write Top CPU usage with %
                ws.write(excel_row, 2 + len(cores), f"{round(top_cpu,2)}%", cell_format)
            note_row = header_row_idx + len(cpuDetails) + 2  # leave one empty row after data
            ws.write(note_row, 3, "Note: Common timestamp details are excluded.", cell_format)
            self.logger.info(f"Filled CPU sheet '{sheetName}' with {len(cpuDetails)} timestamps")
        except Exception as e:
            self.logger.error(f"Error while filling CPU sheet '{sheetName}': {e}")
            raise

    def fillRamData(self, ramData, workSheet, threshold, thresholdValue):
        header_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "#D9E1F2",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )
        title_fmt = self.workBook.add_format(
            {"bold": True, "align": "center", "valign": "vcenter", "border": 2}
        )
        value_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        value_summary_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        # Make the columns a bit wider for readability
        workSheet.set_column(self.cols, self.cols+3, 12)
        workSheet.merge_range(2, self.cols, 2, self.cols+2, 'RAM Usage (%)', header_fmt)
        # Write headers
        row = 3
        workSheet.merge_range(row, self.cols,row+1,self.cols, "Maximum", header_fmt)
        workSheet.merge_range(row, self.cols+1, row+1, self.cols+1, "Minimum", header_fmt)
        workSheet.merge_range(row, self.cols+2, row+1, self.cols+2, "Average", header_fmt)
        row += 2

        max_val = ramData['max']
        min_val = ramData['min']
        avg_val = ramData['avg']
        workSheet.write_number(row, self.cols, max_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+1, min_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+2, avg_val, value_summary_fmt)
        workSheet.write(row+1, self.cols, "Threshold", title_fmt)
        workSheet.write(row+1, self.cols+1, thresholdValue, title_fmt)
        row += 1
        if threshold=='FAIL':
            workSheet.write(row+1, self.cols+1, threshold, self.threshold_worst_fmt)
        else:
            workSheet.write(row+1, self.cols+1, threshold, self.threshold_ok_fmt)
        self.cols += 3

    def fillRomData(self, romData, workSheet, threshold, thresholdValue=21):
        header_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "#D9E1F2",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )
        title_fmt = self.workBook.add_format(
            {"bold": True, "align": "center", "valign": "vcenter", "border": 2}
        )
        value_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        value_summary_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        # Make the columns a bit wider for readability
        workSheet.set_column(self.cols, self.cols+3, 12)
        workSheet.merge_range(2, self.cols, 2, self.cols+2, 'ROM Usage (%)', header_fmt)
        # Write headers
        row = 3
        workSheet.merge_range(row, self.cols,row+1,self.cols, "Maximum", header_fmt)
        workSheet.merge_range(row, self.cols+1, row+1, self.cols+1, "Minimum", header_fmt)
        workSheet.merge_range(row, self.cols+2, row+1, self.cols+2, "Average", header_fmt)
        row += 2
        max_val = romData['max']
        min_val = romData['min']
        avg_val = romData['avg']
        workSheet.write_number(row, self.cols, max_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+1, min_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+2, avg_val, value_summary_fmt)
        workSheet.write(row+1, self.cols, "Threshold", title_fmt)
        workSheet.write(row+1, self.cols+1, thresholdValue, title_fmt)
        row += 1
        if threshold=='FAIL':
            workSheet.write(row+1, self.cols+1, threshold, self.threshold_worst_fmt)
        else:
            workSheet.write(row+1, self.cols+1, threshold, self.threshold_ok_fmt)
        self.cols += 3 
    
    def fillRamSheet(self, ramDetails, fileLink, sheetName="RAM_Utilization"):
        """
        Fill RAM details into an Excel sheet using xlsxwriter.
        First 5 rows are left empty.
        Serial number in first column starting from row 6.
        Timestamp in second column.
        RAM details in subsequent columns with % where required.
        Adds a note at the bottom about duplicate timestamps.
        """
        try:
            ws = self.workBook.add_worksheet(sheetName)
            # Define formats
            header_format = self.workBook.add_format({
                'bold': True, 'align': 'center', 'valign': 'vcenter', 'bg_color': '#D9E1F2', 'border': 1
            })
            cell_format = self.workBook.add_format({'align': 'center', 'valign': 'vcenter', 'border': 1})
            serial_format = self.workBook.add_format({
                'align': 'center', 'valign': 'vcenter', 'border': 1, 'bg_color': '#BDD7EE'
            })
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory of the current script
            relative_path = os.path.relpath(fileLink, current_dir)
            ws.write(18, 1, "Result File Link")
            ws.write(18, 2, relative_path)
            # Header (row 5, index 4)
            header_row_idx = 21
            header = ["S.No", "Timestamp", "RAM Utilization (%)"]
            for col_idx, col_name in enumerate(header):
                ws.write(header_row_idx, col_idx, col_name, header_format)
                ws.set_column(col_idx, col_idx, len(col_name)+4)  # adjust width
            # Fill data starting from row 6 (index 5)
            for row_idx, (timestamp, ram_values) in enumerate(ramDetails.items(), start=1):
                excel_row = header_row_idx + row_idx
                # Serial number
                ws.write(excel_row, 0, row_idx, serial_format)
                # Timestamp
                ws.write(excel_row, 1, timestamp, cell_format)
                # RAM Utilization % (second value)
                ws.write(excel_row, 2, f"{float(ram_values[1]):.2f}%", cell_format)
            # Add note at the bottom
            note_row = header_row_idx + len(ramDetails) + 2
            ws.write(note_row, 3, "Note: Common timestamp details are excluded.", cell_format)
            self.logger.info(f"Filled RAM sheet '{sheetName}' with {len(ramDetails)} timestamps")
        except Exception as e:
            self.logger.error(f"Error while filling RAM sheet '{sheetName}': {e}")
            raise
            
    def fillStackData(self, stackData, workSheet):
        sets = stackData.keys()
        num_sets = len(sets)
        header_fmt = self.workBook.add_format(
            {
                "bold": True,
                "bg_color": "#D9E1F2",
                "align": "center",
                "valign": "vcenter",
                "border": 2,
            }
        )
        title_fmt = self.workBook.add_format(
            {"bold": True, "align": "center", "valign": "vcenter", "border": 2}
        )
        value_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        value_summary_fmt = self.workBook.add_format(
            {"num_format": "0.00", "align": "center", "valign": "vcenter", "border": 1}
        )
        # Make the columns a bit wider for readability
        workSheet.set_column(self.cols, self.cols+3, 12)
        workSheet.merge_range(2, self.cols, 2, self.cols+2, 'STACK Usage (MB)', header_fmt)
        # Write headers
        row = 3
        workSheet.merge_range(row, self.cols,row+1,self.cols, "Maximum", header_fmt)
        workSheet.merge_range(row, self.cols+1, row+1, self.cols+1, "Minimum", header_fmt)
        workSheet.merge_range(row, self.cols+2, row+1, self.cols+2, "Average", header_fmt)
        row += 2
        max_val = stackData['max']
        min_val = stackData['min']
        avg_val = stackData['avg']
        workSheet.write_number(row, self.cols, max_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+1, min_val, value_summary_fmt)
        workSheet.write_number(row, self.cols+2, avg_val, value_summary_fmt)
        row += 1
        self.cols += 3 

    def fillRomSheet(self, romDetails, fileLink, sheetName="ROM_Utilization"):
        """
        Fill ROM utilization data (Timestamp vs % Usage) into an Excel sheet using XlsxWriter.
        Args:
            romDetails (dict): {timestamp: 'percent_usage'}
            sheetName (str): Name of the Excel sheet to create
        """
        try:
            # Create worksheet
            ws = self.workBook.add_worksheet(sheetName)
            # Formats
            blue_format = self.workBook.add_format({'bg_color': '#ADD8E6', 'bold': True})
            header_format = self.workBook.add_format({'bg_color': '#ADD8E6', 'bold': True})
            percent_format = self.workBook.add_format({'num_format': '0.00%'})
         
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory of the current script
            relative_path = os.path.relpath(fileLink, current_dir)
            ws.write(18, 1, "Result File Link")
            ws.write(18, 2, relative_path)
            # Headers
            start_row = 21 
            ws.write(start_row, 0, "Serial", header_format)
            ws.write(start_row, 1, "Timestamp", header_format)
            ws.write(start_row, 2, "ROM Usage (%)", header_format)
            # Fill data
            for idx, (timestamp, usage) in enumerate(romDetails.items(), start=1):
                row = start_row + idx
                ws.write(row, 0, idx, blue_format)              # Serial column with blue fill
                ws.write(row, 1, timestamp)                    # Timestamp
                ws.write(row, 2, float(usage)/100)             # Usage as decimal for % format
                ws.set_column(2, 2, 15, percent_format)        # Apply percent format
            # Add note
            note_row = start_row + len(romDetails) + 2
            ws.write(note_row, 3, "Note: common timestamp details are excluded")
            self.logger.info(f"{sheetName} sheet filled successfully with {len(romDetails)} entries.")
        except Exception as e:
            self.logger.error(f"Error filling {sheetName} sheet: {e}")
            raise

    def fillConsumptionData(self):
        workSheetName = 'TestResultSummary'
        workSheet = self.workBook.add_worksheet(workSheetName)
        self.labelFormat(100, 100, 1, '#FFFFFF', workSheet)
        self.setFormat()
        for os, specs in self.consumptionData.items():
            if os.lower() == 'linux':
                workSheet.write(2, 0, u'\u25B8 Linux')
                for spec, details in specs[0].items():
                    if spec == 'cpu' and details[1] and details[0]:
                        fileLink = specs[1]['cpu_util']
                        self.fillCpuSheet(details[1], fileLink)
                        self.fillCpuData(details[0], workSheet, details[-2], details[3])
                    elif spec == 'ram' and details[1] and details[0]:
                        fileLink = specs[1]['mem_details_linux']
                        self.fillRamSheet(details[1], fileLink)
                        self.fillRamData(details[0], workSheet, details[-2], details[3])
                    elif spec == 'rom' and details[1] and details[0]:
                        fileLink = specs[1]['mem_details_linux']
                        self.fillRomSheet(details[1], fileLink)
                        self.fillRomData(details[0], workSheet, details[-2], details[3])
                    elif spec == 'stack' and details[1] and details[0]:
                        self.fillStackData(details[0], workSheet)
            elif os.lower() == 'qnx':
                workSheet.write(12, 1, u'\u25B8 QNX')
                for spec, details in specs.items():
                    print(f"{spec}: {details} \n")
        return workSheetName
        
    def closeWorkBook(self):
        self.workBook.close()

    def run(self):
        self.workBook, workBookPath = self.createWorkBook()
        self.createDefaultSheets()
        workSheet = self.fillConsumptionData()
        self.closeWorkBook()
        return workBookPath, workSheet
