from .ram_usage_parser import RAMUsageParser
from .rom_usage_parser import ROMUsageParser
from .stack_usage_parser import STACKUsageParser
from .cpu_usage_parser import CPUUsageParser

class ParserFactory:
    """
    Factory class to create parser instances.
    """

    @staticmethod
    def create_parser(parser_type, logger):
        """
        Creates a parser instance based on the given type.

        Args:
        parser_type (str): The type of parser to create (e.g., 'ram', 'rom', 'stack').
        logger (object): The logger instance to use.

        Returns:
        object: The created parser instance.
        """
        parsers = {
            'cpu': CPUUsageParser,
            'ram': RAMUsageParser,
            'rom': ROMUsageParser,
            'stack': STACKUsageParser
        }

        if parser_type in parsers:
            return parsers[parser_type](logger)
        else:
            print(f"Unsupported parser type: {parser_type}")
            raise ValueError(f"Unsupported parser type: {parser_type}")