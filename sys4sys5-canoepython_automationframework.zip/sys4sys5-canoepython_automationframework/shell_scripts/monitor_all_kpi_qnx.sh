#!/bin/sh

# Duration and output directory
DURATION=${1:-60}
OUTDIR=${2:-/data/sys4sys5/tmp}

mkdir -p "$OUTDIR"

CPU_LOG="$OUTDIR/cpu_hogs.txt"
CORE_UTILIZATION="$OUTDIR/core_cpu_summary.txt"
RAM_LOG="$OUTDIR/ram_pidin.txt"
ROM_LOG="$OUTDIR/rom_df.txt"

# Clear logs
: > "$CPU_LOG"
: > "$CORE_UTILIZATION"
: > "$RAM_LOG"
: > "$ROM_LOG"

echo "[INFO] Capturing CPU, RAM, and ROM for $DURATION seconds..."
###############################
# CPU Logging
###############################
log_cpu() {
    END=$((SECONDS + DURATION))
    echo "TimeStamp" = "Cpu Usage" >> "$CORE_UTILIZATION"
    while [ $SECONDS -lt $END ]; do
        timestamp=$(date +%T)
        echo "[$timestamp]" >> "$CPU_LOG"
        # Capture hogs output
        hogs_output="/tmp/hogs_tmp.txt"
        hogs -s1 -p20 -i1 > "$hogs_output"
        cat "$hogs_output" >> "$CPU_LOG"
        # Calculate idle core utilization
        core_sum=0
        while read line; do
            echo "$line" | grep -q "\[idle\]" || continue
            util=$(echo "$line" | awk '{
                for(i=1;i<=NF;i++){
                    if ($i ~ /%$/) {
                        gsub("%","",$i);
                        print $i;
                        break;
                    }
                }
            }')
            [ -n "$util" ] && core_sum=$((core_sum + util))
        done < "$hogs_output"
        remaining=$((100 - core_sum))
        echo "$timestamp = $remaining" >> "$CORE_UTILIZATION"
        sleep 1
    done
}

###############################
# RAM Logging
###############################
log_ram() {
    END=$((SECONDS + DURATION))
    while [ $SECONDS -lt $END ]; do
        echo "[$(date +%T)]" >> "$RAM_LOG"
        pidin memory >> "$RAM_LOG"
        sleep 1
    done
}

###############################
# ROM Logging
###############################
log_rom() {
    END=$((SECONDS + DURATION))
    while [ $SECONDS -lt $END ]; do
        echo "[$(date +%T)]" >> "$ROM_LOG"
        df -h >> "$ROM_LOG"
        sleep 1
    done
}

# Run all loggers in background
log_cpu &
log_ram &
log_rom &

wait
echo "[INFO] Monitoring complete. Logs saved in $OUTDIR"
 