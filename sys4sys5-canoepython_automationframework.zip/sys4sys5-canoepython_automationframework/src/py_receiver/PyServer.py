from constants import ERROR_CODE_1000, ERROR_CODE_1001
import constants
import socket
import json
import threading
import argparse
import logging
import os
import subprocess
from pathlib import Path
from flagManager import FlagManager
from timer import Timer
import importlib


# Setup logging
LOG_DIR = "../../logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "PyServer.log")
active_connections = []
logLevel = FlagManager.read_log_level()

# relative scripts path for central execution point
REMOTE_DATA_SCRIPT_FOR_CHECK_ECU = "../remote_data_collection/check_ecu_status.py"
REMOTE_DATA_SCRIPT_FOR_IDLE_STATS = "../remote_data_collection/linux_IDLE_data.py"
REMOTE_DATA_SCRIPT = "../remote_data_collection/RunRemoteTest_Via_SSH.py"
RESOURCES_PARSER_SCRIPT = "../resources_parser/main.py"
DLT_CAPTURE_SCRIPT = "../DLT_Capture_Script/DLT_Capture.py"
DLT_PROCESSING_SCRIPT = "../dlt_validator/DLT_validator.py"
PCAP_PROCESSING_SCRIPT = "../pcap_validator/pcap_validator.py"

# returns respective log level
def getLogLevel(logLevel):
    if logLevel=='logging.INFO':
        return logging.INFO
    elif logLevel=='logging.ERROR':
        return logging.ERROR
    elif logLevel=='logging.WARNING':
        return logging.WARNING
    elif logLevel=='logging.DEBUG':
        return logging.ERROR
    elif logLevel=='logging.CRITICAL':
        return logging.CRITICAL

logging.basicConfig(
    level=getLogLevel(logLevel),
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

def load_config(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"[CONFIG] File not found: {path}", exc_info=True)
    except json.JSONDecodeError as e:
        logging.error(f"[CONFIG] JSON parsing failed: {e}", exc_info=True)
    except Exception as e:
        logging.error(f"[CONFIG] Unexpected error: {e}", exc_info=True)
        print(f"[CONFIG] Unexpected error: {e}", exc_info=True)
    return {}

def run_remote_data_script_for_checking_ecu():
    try:
        process = subprocess.Popen([
            "python", REMOTE_DATA_SCRIPT_FOR_CHECK_ECU
        ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

        output_lines = []
        json_candidate = None

        logging.info(f"[RemoteScript for Check ECU] : Trying to connect..")
        print(f"[RemoteScript for Check ECU] : Trying to connect..")

        for line in process.stdout:
            line = line.strip()
            output_lines.append(line)
            if ERROR_CODE_1000 in line or ERROR_CODE_1001 in line:
                process.returncode = -1
                raise ConnectionError("Remote data script encountered a connection issue. please check environmentConfig input values.")
            #logging.info(f"[RemoteScript ] {line}")

            try:
                json_candidate = json.loads(line)
            except json.JSONDecodeError:
                pass  # Not JSON, continue

        process.wait()
        print(f"[PyServer] : script completed.")
        return process.returncode, json_candidate

    except ConnectionError as e:  # Catch the specific ConnectionError
        logging.error(f"[PyServer] Connection failed: {e}", exc_info=True)
        return -1, None
    except Exception as e:
        logging.error(f"[RemoteScript for Check ECU] Execution failed: {e}", exc_info=True)
        return -1, None

def run_remote_data_script_for_idle_stats(app_name, use_case_name):
    try:
        process = subprocess.Popen([
            "python", REMOTE_DATA_SCRIPT_FOR_IDLE_STATS,
            "--app", app_name,
            "--usecase", use_case_name
        ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

        output_lines = []
        json_candidate = None

        logging.info(f"[RemoteScript for Idle stats] : Fetching Data from ECU")
        print(f"[RemoteScript for Idle stats] : Fetching Data from ECU")

        for line in process.stdout:
            line = line.strip()
            output_lines.append(line)
            if ERROR_CODE_1000 in line or ERROR_CODE_1001 in line:
                process.returncode = -1
                raise ConnectionError("Remote data script encountered a connection issue. please check environmentConfig input values.")

            #logging.info(f"[RemoteScript ] {line}")

            try:
                json_candidate = json.loads(line)
            except json.JSONDecodeError:
                pass  # Not JSON, continue

        process.wait()
        print(f"[PyServer] : script completed.")
        return process.returncode, json_candidate

    except ConnectionError as e:  # Catch the specific ConnectionError
        logging.error(f"[PyServer] Connection failed: {e}", exc_info=True)
        return -1, None
    except Exception as e:
        logging.error(f"[RemoteScript for Idle stats] Execution failed: {e}", exc_info=True)
        return -1, None


def run_remote_data_script(app_name, use_case_name):
    try:
        process = subprocess.Popen([
            "python", REMOTE_DATA_SCRIPT,
            "--app", app_name,
            "--usecase", use_case_name
        ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

        output_lines = []
        json_candidate = None

        logging.info(f"[PyServer] : Fetching Data from ECU")
        print(f"[PyServer] : Fetching Data from ECU")

        for line in process.stdout:
            line = line.strip()
            output_lines.append(line)
            if ERROR_CODE_1000 in line or ERROR_CODE_1001 in line:
                process.returncode = -1
                raise ConnectionError("Remote data script encountered a connection issue. please check environmentConfig input values.")
            #logging.info(f"[RemoteScript ] {line}")

            try:
                json_candidate = json.loads(line)
            except json.JSONDecodeError:
                pass

        process.wait()
        print(f"[PyServer] : script completed.")
        return process.returncode, json_candidate

    except ConnectionError as e:  # Catch the specific ConnectionError
        logging.error(f"[PyServer] Connection failed: {e}", exc_info=True)
        return -1, None

    except Exception as e:
        logging.error(f"[PyServer] Execution failed: {e}", exc_info=True)
        return -1, None

def run_resource_validator_script(generatedFolderName, inputArgs):
    try:
        process = subprocess.Popen([
            "python", RESOURCES_PARSER_SCRIPT,
            "--logsDir", generatedFolderName,
            "--osType", "linux",
            "--perfParam", inputArgs,
            "--logLevel", logLevel
        ],)

    except Exception as e:
        logging.error(f"[RESOURCE VALIDATOR] Execution failed: {e}", exc_info=True)

def run_pcap_validator_script(app_name, useCase, pcapPath, resultPath):
    try:
        process = subprocess.Popen([
            "python", PCAP_PROCESSING_SCRIPT,
            "--app", app_name,
            "--usecase", useCase,
            "--pcapPath", pcapPath,
            "--resultPath", resultPath,
        ], )

    except Exception as e:
        logging.error(f"[PCAP Validation] Execution failed: {e}", exc_info=True)

def run_dlt_validator_script(app_name, dlt_path, result_path):
    try:
        full_path = os.path.realpath(result_path)
        #print(f"dlt_path and result_path :  {dlt_path},{result_path}")
        #result_path=result_path+"/linux"
        full_path=full_path+"/linux/"+dlt_path
        #print(f"dlt_path and result_path :  {dlt_path},{result_path}")
        process = subprocess.Popen([
            "python", DLT_PROCESSING_SCRIPT,
            "--app", app_name,
            "--dltpath", full_path,
            "--resultPath", result_path,
        ], )

    except Exception as e:
        logging.error(f"[DLT Validation] Execution failed: {e}", exc_info=True)

def start_server(conn, addr, flagManagerObj):
    executed_KPIs = ""
    active_connections.append((conn, addr))
    logging.info(f"[PyServer] Connected to {addr}")
    print(f"[PyServer] Connected to {addr}")
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                logging.warning("[PyServer] No data received.")
                return

            request = json.loads(data.decode('cp1252'))
            logging.info(f"[PyServer] Request received: {request}")

            print(f"[PyServer] Request received: {request}")

            app_name = request.get("Application", "")
            test_type = request.get("TestType", "")
            use_case_name = request.get("TestCase", "")
            action_type = request.get("Action_type", "")
            
            print("\n")
            print(f"-----------------------[{use_case_name}][START]-----------------------")
            print("\n")

            # Step 1: Run remote data collection for IDLE ECU/LINUX Stats

            if "Check ECU" == action_type:
                try:
                    print(f"[PyServer] Starting idle status script.")
                    return_code, output = run_remote_data_script_for_checking_ecu()
                    print(f"[PyServer] idle status script completed.")
                    logging.info(f"[PyServer] Remote script finished with code {return_code}")
                    logging.info(f"[PyServer] Remote script finished with data {output}")
                except Exception as e:
                    print("[start_server] Exception while run_remote_data_script_for_checking_ecu, error: ", e)

                print(f"return_code: {return_code}")
                if return_code == 0:
                    flagManagerObj.set_successful()
                    executed_KPIs += "ECU Status Check Done,"
                    response = {"responseData": "ECU conection status check Success."}
                else:
                    flagManagerObj.set_False()
                    response = {"responseData": "ECU conection status check failed."}

                conn.send(json.dumps(response).encode('cp1252'))
                logging.info("[PyServer] Response sent successfully.")

            elif "Get Idle Stats" == action_type:
                try:
                    print(f"[PyServer] Starting idle status script.")
                    return_code, output = run_remote_data_script_for_idle_stats(app_name, use_case_name)
                    print(f"[PyServer] idle status script completed.")
                    logging.info(f"[PyServer] Remote script finished with code {return_code}")
                    logging.info(f"[PyServer] Remote script finished with data {output}")
                except Exception as e:
                    print("[start_server] Exception while run_remote_data_script_for_idle_stats, error: ", e)

                if return_code == 0:
                    flagManagerObj.set_successful()  #needs to check removed for any reason 
                    executed_KPIs += "Remote Fetch Done,"
                    response = {"responseData": "Initial ECU/WSL resources stats fetch done."}
                else:
                    flagManagerObj.set_False() #needs to check removed for any reason 
                    response = {"responseData": "Initial ECU/WSL resources stats fetch failed."}

                conn.send(json.dumps(response).encode('cp1252'))
                logging.info("[PyServer] Response sent successfully.")

            # Step 2: Run remote data collection during Testing
            elif "Start Test" == action_type:
                
                if flagManagerObj.get_status():
                    response = {
                        "responseData": "Flag 'isInitialDataFetchSuccessful' is set True, proceed for testing."
                    }

                    conn.send(json.dumps(response).encode('cp1252'))
                    logging.info("[PyServer] Response sent successfully.")
                    
                    #conn.close()
                    #active_connections.remove((conn, addr))
                    print(f"[PyServer] Starting remote data collection script.")
                    return_code, output = run_remote_data_script(app_name, use_case_name)
                    print(f"[PyServer] remote data collection script completed.")
                    logging.info(f"[PyServer] Remote script finished with code {return_code}")
                    logging.info(f"[PyServer] Remote script finished with data {output}")

                    #flagManagerObj.set_False()

                    if return_code == 0:
                        executed_KPIs += "Remote Fetch Done,"

                    try:
                        if output is None:
                            response = {
                                "responseData": "[Error]: Issue with remote script, the output path couldn't be generated."
                            }
                            conn.send(json.dumps(response).encode('cp1252'))
                            logging.info("[PyServer] Response sent successfully.")


                        normalized_path = Path(output['TestRawPath']).as_posix()
                        folderName = normalized_path.split("/")[-1]

                        resourceParams = ["cpu", "ram", "rom", "stack"]
                        wholeResourceRequests = test_type.lower()
                        filteredResourceRequests = ",".join([resource.upper() for resource in resourceParams if resource in wholeResourceRequests])

                        #post processing starts
                        if filteredResourceRequests:
                            logging.info(f"[PyServer] Resource usage validation started for {app_name}")
                            print(f"[PyServer] Parser script started")
                            run_resource_validator_script(folderName, filteredResourceRequests)

                        if "pcap" in wholeResourceRequests:
                            pcap_path = normalized_path + "/pcap/" + use_case_name +"_networkCapture_" + constants.generatedTimeStamp + ".pcap"
                            run_pcap_validator_script(app_name, use_case_name, pcap_path, normalized_path)
                            logging.info(f"[PyServer] pcap validation script triggered for {app_name}")
                        '''
                        if "dlt" in wholeResourceRequests:
                            dlt_file = "DLT_Log.dlt"
                            run_dlt_validator_script(app_name, dlt_file, normalized_path)
                            logging.info(f"[PyServer] dlt validation script triggered for {app_name}")
                        '''
                        #post processing ends
                    except Exception as e:
                        print("[start_server] Issue in start test method, error:", e)
                                            
                    response = {
                        "responseData": "Test Executed"
                    }
                    
                else:
                    logging.warning(f"Initial Data fetch flag is False, seems issue in previous operation.")

            else:
                response = {
                        "responseData": "[Error]: The request data is invalid. Please provide valid request."
                    }
                conn.send(json.dumps(response).encode('cp1252'))
                logging.info("[PyServer] Response sent successfully.")
        
            print("\n")
            print(f"-----------------------[{use_case_name}][END]-----------------------")
            print("\n")
        
    except Exception as e:
        logging.error(f"[PyServer] Error during client handling: {e}", exc_info=True)
    finally:
        #pass
        conn.close()
        active_connections.remove((conn, addr))

def run_daemon(host, port):
    try:
        flagManagerObj = FlagManager()
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((host, port))
        server_socket.listen()
        server_socket.settimeout(1.0)
        logging.info(f"[PyServer] Multi-threaded TCP daemon running on {host}:{port}")
        print(f"[PyServer] Started server in listening mode.")
        while True:
            try:
                conn, addr = server_socket.accept()
                client_thread = threading.Thread(target=start_server, args=(conn, addr, flagManagerObj))
                client_thread.start()
            except socket.timeout:
                continue
            except Exception as e:
                logging.error(f"[PyServer] Error in accept loop: {e}", exc_info=True)
                print(f"[PyServer] Error encounterred in accepting the client request.")
    except KeyboardInterrupt:
        print("[PyServer] KeyBoard interrupt given.")
        logging.info("[PyServer] Shutdown requested by user (CTRL+C).")
    finally:
        logging.info("[PyServer] Closing active connections...")
        for conn, addr in active_connections:
            try:
                shutdown_msg = {
                    "Status": "Server shutting down",
                    "Application": "N/A",
                    "Results": None
                }
                conn.send(json.dumps(shutdown_msg).encode('cp1252'))
                conn.close()
                logging.info(f"[PyServer] Notified and closed connection with {addr}")
            except Exception as e:
                logging.warning(f"[PyServer] Failed to notify {addr}: {e}", exc_info=True)

        server_socket.close()
        logging.info("[PyServer] Server socket closed.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start Python socket server")
    parser.add_argument("--host", help="Host IP to bind")
    parser.add_argument("--port", type=int, help="Port to bind")
    parser.add_argument("--config", default="../../configs/pyServerConfig.json", help="Path to config file")

    args = parser.parse_args()
    config = load_config(args.config)
    HOST = args.host or config.get("host", "127.0.0.1")
    PORT = args.port or config.get("port", 5055)
    
    Timer.createTimeStamp()

    importlib.reload(constants)
    # Reload constants to get the updated timestamp
    if Timer.getTimeStamp() is not None:
        run_daemon(HOST, PORT)
    else:
        print("Error occurred while retrieving timestamp.")