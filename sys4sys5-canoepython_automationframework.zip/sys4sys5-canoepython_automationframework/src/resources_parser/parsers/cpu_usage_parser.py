import re
from datetime import date
import threading 
import time
import os
import sys

class CPUUsageParser:
    """
        This class takes in CPU usage data, extracts and processes the relevant details
    """

    # Number of CPU cores available on the Linux machine
    cpuCoreCountInLinux=0

    def __init__(self, logger):
        self.logger = logger
        self.avg=0
        self.logger.info("CPUUsageParser::__init__ instance created.")

    def processLinuxCpuUtilization(self, topDetails):
        """
        Processes CPU details to calculate max, min, and average utilization per core independently.
        Args:
            topDetails (dict): {timestamp: [[cpu_dict1, top_cpu1], [cpu_dict2, top_cpu2], ...]}
        Returns:
            dict: Summary containing max, min, and avg per core.
        """
        try:
            self.logger.info("CPUUsageParser::processCpuUtilization Processing results...")
            if not topDetails:
                self.logger.error("CPUUsageParser::processCpuUtilization cpu details are empty")
                raise ValueError("Cpu details are empty")
            summary = {
                "max_utilization": {},
                "min_utilization": {},
                "avg_utilization": {}
            }
            sum_utilization = {}
            count_utilization = {}
            for timestamp, entry in topDetails.items():
                cpu_dict, top_cpu = entry
                self.logger.debug(f"Processing timestamp: {timestamp}")
                for core, value in cpu_dict.items():
                    try:
                        utilization = float(value)
                    except (TypeError, ValueError):
                        self.logger.error(f"Invalid utilization for core {core} at timestamp {timestamp}")
                        continue
                    # Update max
                    if core not in summary["max_utilization"] or utilization > summary["max_utilization"][core]:
                        summary["max_utilization"][core] = utilization
                    # Update min
                    if core not in summary["min_utilization"] or utilization < summary["min_utilization"][core]:
                        summary["min_utilization"][core] = utilization
                    # Sum and count for average
                    sum_utilization[core] = sum_utilization.get(core, 0) + utilization
                    count_utilization[core] = count_utilization.get(core, 0) + 1
            # Calculate averages and round everything to 2 decimals
            for core in sum_utilization:
                summary["avg_utilization"][core] = round(sum_utilization[core] / count_utilization[core], 2)
                summary["max_utilization"][core] = round(summary["max_utilization"][core], 2)
                summary["min_utilization"][core] = round(summary["min_utilization"][core], 2)
            self.logger.info("CPUUsageParser::processCpuUtilization Finished processing results....")
            return {"Summary": summary}
        except Exception as e:
            self.logger.error(f"CPUUsageParser::processCpuUtilization An error occurred: {str(e)}")
            raise

    def linuxLogExtractor(self, logFile):
        """
            Fetches CPU utilization data from a log file.

            Args:
            logFile (str): The path to the log file containing CPU utilization data.

            Returns:
            dict: A dictionary containing the CPU utilization details, where each key represents a time interval and the corresponding value is another dictionary with core IDs as keys and their utilization values as values.

            Note:
            This function uses regular expressions to parse the log file and extract the CPU utilization data. It also updates the global variable `cpuCoreCountInLinux` with the maximum number of CPU cores encountered in the log file.
        """
        self.logger.info(f"Extracting CPU utilization data from log file: {logFile}")

        topDetails = {}

        if not os.path.isfile(logFile):
            raise FileNotFoundError(f"The file '{logFile}' does not exist.")
        try:
            with open(logFile, 'r') as f:
                content = f.read()
        except Exception as e:
            self.logger.error(f"Error reading file '{logFile}': {e}")
            raise
        # Normalize newlines
        content = content.replace('\u2028', '\n').replace('\u2029', '\n')
        blocks = content.split("Timestamp:")[1:]  # skip first empty split
        for block in blocks:
            lines = block.strip().splitlines()
            if not lines:
                continue
            timestamp = lines[0].strip()
            # Skip duplicate timestamps
            if timestamp in topDetails:
                self.logger.info(f"Ignoring duplicate timestamp: {timestamp}")
                continue
            cpu_dict = {}
            top_cpu = None
            for line in lines[1:]:
                line = line.strip()
                try:
                    if line.startswith("CPU"):
                        match = re.match(r"(CPU\d+):\s*([\d.]+)%", line)
                        if match:
                            core, value = match.groups()
                            cpu_dict[core] = float(value)
                    elif line.startswith("Top command CPU usage:"):
                        top_cpu = float(line.split(":")[1].strip().replace("%", ""))
                except Exception as e:
                    self.logger.warning(f"Warning: Could not parse line '{line}' in timestamp {timestamp}: {e}")
            if cpu_dict and top_cpu is not None:
                topDetails[timestamp] = [cpu_dict, top_cpu]
            else:
                self.logger.warning(f"Warning: Missing data for timestamp {timestamp}")
        return topDetails
    
    def qnxLogExtractor(self, logFile):
        """
            Fetches CPU utilization data from a log file.

            Args:
            logFile (str): The path to the log file containing CPU utilization data.

            Returns:
            dict: A dictionary containing the CPU utilization details, where keys are 'maximum', 'minimum', 'average', and 'timestamp_data'.
                'maximum', 'minimum', and 'average' each have a float value representing the CPU utilization.
                'timestamp_data' is a dictionary with time intervals as keys and their corresponding utilization values as values.

            Note:
            This function uses regular expressions to parse the log file and extract the CPU utilization data.
        """
        self.logger.info(f"Extracting CPU utilization data from log file: {logFile}")

        cpu_data = []
        timestamp_data = {}

        if not os.path.isfile(logFile):
            raise FileNotFoundError(f"The file '{logFile}' does not exist.")

        try:
            with open(logFile, 'r') as f:
                for line in f:
                    match = re.search(r'(\d{2}:\d{2}:\d{2}) = (\d+)', line)
                    if match:
                        timestamp = match.group(1)
                        utilization = int(match.group(2))
                        cpu_data.append(utilization)
                        timestamp_data[timestamp] = utilization
        except Exception as e:
            self.logger.error(f"Error reading file '{logFile}': {e}")
            raise

        if not cpu_data:
            return {
                'maximum': 0.0,
                'minimum': 0.0,
                'average': 0.0,
                'timestamp_data': timestamp_data
            }

        maximum = float(max(cpu_data))
        minimum = float(min(cpu_data))
        average = float(sum(cpu_data) / len(cpu_data))

        topDetails = {
            'maximum': maximum,
            'minimum': minimum,
            'average': average,
            'cpuStats': timestamp_data
        }
        
        return topDetails

    def run(self, osType, logFile, readConfig):
        print(f"Parsing {logFile}")
        if osType=='linux':
            threshold = 0
            topDetails = self.linuxLogExtractor(logFile)
            try:
                threshold = float(readConfig['LINUX']['CPU']['threshold'])
                if ((float(threshold) > 100 or float(threshold)<0)):
                    self.logger.error(f"CPUUsageParser::run Please provide the proper threshold value in JSON!")
                    raise Exception("CPUUsageParser::run Please provide the proper threshold value in JSON!")
            except Exception as e:
                self.logger.error(f"CPUUsageParser::run Please provide the proper threshold value in JSON!")
                print(f"Please provide the proper threshold value in JSON! \t Exiting gracefully...")
                sys.exit(0)
            sets = self.processLinuxCpuUtilization(topDetails)
            if self.avg<threshold:
                return [sets, topDetails, 'PASS', threshold]
            else:
                return [sets, topDetails, 'FAIL', threshold]
        elif osType=='qnx':
            self.logger.info(f"CPUUsageParser::run Processing QNX CPU usage details")
            threshold = 0
            topDetails = self.qnxLogExtractor(logFile)
            try:
                threshold = float(readConfig['QNX']['CPU']['threshold'])
                if ((float(threshold) > 100 or float(threshold)<0)):
                    self.logger.error(f"CPUUsageParser::run Please provide the proper threshold value in JSON!")
                    raise Exception("CPUUsageParser::run Please provide the proper threshold value in JSON!")
            except Exception as e:
                self.logger.error(f"CPUUsageParser::run Please provide the proper threshold value in JSON!")
                print(f"Please provide the proper threshold value in JSON! \t Exiting gracefully...")
                sys.exit(0)
            if self.avg<threshold:
                return [topDetails, 'PASS', threshold]
            else:
                return [topDetails, 'FAIL', threshold]