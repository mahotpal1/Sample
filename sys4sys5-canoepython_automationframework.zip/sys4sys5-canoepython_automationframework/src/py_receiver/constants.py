logLevel = "logging.INFO"

#logLevel='logging.INFO'
#logLevel='logging.ERROR'
#logLevel='logging.WARNING'
#logLevel='logging.DEBUG'
#logLevel='logging.CRITICAL'

ERROR_CODE_1000 = "WinError 10060"
ERROR_CODE_1001 = "Authentication failed"
generatedTimeStamp = '20251106_125353'
