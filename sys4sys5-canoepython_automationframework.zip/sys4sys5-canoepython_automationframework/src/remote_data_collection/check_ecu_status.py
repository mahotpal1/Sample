import paramiko
import threading
import sys
import os
import time
import stat
import logging
import json
from scp import SCPClient
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'py_receiver'))) 
from flagManager import FlagManager


logLevel = FlagManager.read_log_level()

# returns respective log level
def getLogLevel(logLevel):
    if logLevel=='logging.INFO':
        return logging.INFO
    elif logLevel=='logging.ERROR':
        return logging.ERROR
    elif logLevel=='logging.WARNING':
        return logging.WARNING
    elif logLevel=='logging.DEBUG':
        return logging.ERROR
    elif logLevel=='logging.CRITICAL':
        return logging.CRITICAL


def load_config(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"[CONFIG] File not found: {path}", exc_info=True)
    except json.JSONDecodeError as e:
        logging.error(f"[CONFIG] JSON parsing failed in '{path}': {e}", exc_info=True)
    except Exception as e:
        logging.error(f"[CONFIG] Unexpected error loading '{path}': {e}", exc_info=True)
    return None

def setup_logging():
    try:
        logging.basicConfig(
            level=getLogLevel(logLevel),
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[
                logging.StreamHandler()
            ]
        )
    except Exception as e:
        print(f"[ERROR] Failed to set up logging: {e}")
        exit(1)

def run_remote_operations(ipAddress, operatingSystem, username, password):
    #host_logger = get_host_logger(ipAddress, operatingSystem)
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ipAddress, username=username, password=password)

        # Open SFTP session
        sftp = ssh.open_sftp()
        sftp.close()
        ssh.close()

    except Exception as e:
        logging.error(f"Exception: {e}", exc_info=True)
        print(f"[ERROR] Host: {ipAddress},  Error: {e}")

def start_processing():
    try:
        thread_list = []
        count = 0

        for host in hosts:
            ipAddress = host["ipAddress"]
            username = host["username"]
            password = host["password"]
            operatingSystem = host["operatingSystem"]

            thread = threading.Thread(
                target=run_remote_operations,
                args=(ipAddress, operatingSystem, username, password)
            )
            thread_list.append(thread)
            thread.start()
            #logging.info(f"[THREAD] Started: {script_name} on {ipAddress} for mode={mode}")

        for thread in thread_list:
            thread.join()

    except Exception as e:
        logging.critical(f"[PROCESSING] Fatal error during execution: {e}", exc_info=True)
        print(f"[FATAL] Error during processing: {e}")
        return {
            "TestRawPath": None,
            "Error": str(e)
        }

    TR = {
            "Status": "Success"
    }
    logging.info(f"Result : {str(TR)}")
    
    return TR

if __name__ == "__main__":
    config = load_config("../../configs/environmentConfig.json")
    
    hosts = config["hosts"]
    if config is None:
        logging.critical("[CONFIG] Cannot continue without valid configuration.")
        exit(1)
    
    setup_logging()

    result = start_processing()

    print(json.dumps(result))
