import threading
import constants

class FlagManager:
    def __init__(self):
        self._isInitialDataFetchSuccessful = False
        self._lock = threading.Lock()

    def set_successful(self):
        with self._lock:
            self._isInitialDataFetchSuccessful = True
            
    def set_False(self):
        with self._lock:
            self._isInitialDataFetchSuccessful = False

    def get_status(self):
        with self._lock:
            return self._isInitialDataFetchSuccessful
    
    def read_log_level():
        """Reads the value of logLevel from constants.py."""
        return constants.logLevel

    def write_log_level(new_value):
        """Writes the new value of logLevel to constants.py, 
        replacing the existing line safely."""

    # Read the entire content of constants.py
        with open("constants.py", "r") as f:
            lines = f.readlines()

    # Find and replace the line containing isLogEnabled
        for i, line in enumerate(lines):
            if "logLevel" in line:
                lines[i] = "logLevel = " + str(new_value) + "\n"
                break  # Stop after replacing the first occurrence

    # Write the modified content back to constants.py
        with open("constants.py", "w") as f:
            f.writelines(lines)
