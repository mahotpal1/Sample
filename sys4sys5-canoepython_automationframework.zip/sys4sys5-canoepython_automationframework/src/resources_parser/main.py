from utils import logger
from processors import log_processor, utilization_processor
import os
from datetime import datetime
import argparse
import sys
import time 
import json

logDirName = 'logs'
logSubDirName = 'Workbook_Graph_Logs'
configFileLoc = '../../configs/reportGeneratorConfig.json'
resultsFolderLoc = '../../results'
reportDir = '../../Workbook_Graph_Report'

def main():
    # Record start time
    start_time = time.time()
    # Add the argument parser for specific folder results.
    parser = argparse.ArgumentParser(description='Process logs and generate reports')
    parser.add_argument('--logsDir', help='Directory containing logs', required=True)
    parser.add_argument('--osType', help='Type of operating system', required=True)
    parser.add_argument('--perfParam', help='Performance parameter', required=True)
    parser.add_argument('--logLevel', help='Log Level', required=False)
    args = parser.parse_args()
    # setup logger
    logFileLocation = ''
    try:
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        logFileLocation = os.path.join(project_root, logDirName, logSubDirName)
        if not os.path.exists(logFileLocation):
            os.makedirs(logFileLocation)
    except Exception as e:
        print(f"Main::main Error setting up logger: {str(e)}")
        exit(1)

    if not args.logsDir or not args.osType or not args.perfParam:
            print("Main::main Please provide proper inputs i.e \n--logsDir: [Folder Name]\n--osType: [Os type for which reports needs to be generated] \n--perfParam: [RAM|ROM|CPU|STACK|ALL or string seperated with comma for multiple KPI's] \n--logLevel: logLevel")
            return {"PASS": 0, "Fail": "Invalid Input Arguments"} 

    loggerInst = logger.LoggerSingleton().getLogger(logFileLocation, args.logLevel)
    loggerInst.info("Main::main Logger setup complete")
    returnJson = {"PASS": 1, "FAIL": ""}
    try:
        # Execute log processor
        logProcessor = log_processor.LogProcessor(configFileLoc, resultsFolderLoc, loggerInst, args)
        returnJson = logProcessor.run()
        if returnJson['PASS'] == 0:
            return returnJson
        # process report generation
        utilizationProcessor = utilization_processor.UtilizationProcessor(loggerInst, reportDir, configFileLoc)
        utilizationProcessor.processReports()
        return returnJson
    except KeyboardInterrupt:
        print("\nMain::main Keyboard interrupt detected. Exiting gracefully...")
        sys.exit(0)
    finally:
        # Record end time and print duration
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"\nMain::Report generator Script executed in {elapsed_time:.2f} seconds")
        
if __name__ == "__main__":
    returnJson = main()
    print(json.dumps(returnJson))
 