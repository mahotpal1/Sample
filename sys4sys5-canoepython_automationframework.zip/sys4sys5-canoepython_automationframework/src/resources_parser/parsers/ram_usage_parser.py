import re
from datetime import date
import threading 
import time
import sys

class RAMUsageParser:
    """
        This class takes in RAM usage data, extracts and processes the relevant details
    """

    def __init__(self, logger):
        self.logger = logger
        self.avg = 0
        self.logger.info("RAMUsageParser instance created.")

    def processLinuxRamUtilization(self, ramDetails):
        """
        Processes the Ram details for report and graph generation.

        Args:
        ramDetails (dict): A dictionary containing the ram utilization details.

        Returns:
        dict: A dictionary containing the overall average, maximum, and minimum utilization.
        """
        try:
            self.logger.info("RAMUsageParser::processLinuxRamUtilization Processing results...")
            # Handle cases if dictionary is empty
            if not ramDetails:
                self.logger.error("RAMUsageParser::processLinuxRamUtilization ramDetails is empty")
                return {}

            # Extract used_consumptions, handling 'n/a' values
            used_consumptions = []
            for key in ramDetails:
                value = ramDetails[key]
                used_consumptions.append(float(value[1]))

            # Calculate min, max, and average
            if not used_consumptions:
                self.logger.error("RAMUsageParser::processLinuxRamUtilization No valid ram utilization data found.")
                raise ValueError("No valid ram utilization data found.")
                
            min_utilization = min(used_consumptions)
            max_utilization = max(used_consumptions)
            avg_utilization = sum(used_consumptions) / len(used_consumptions)

            self.avg = avg_utilization  # Store the overall average

            results = {
                'min': min_utilization,
                'max': max_utilization,
                'avg': avg_utilization
            }

            return results

        except Exception as e:
            print(f"RAMUsageParser::processLinuxRamUtilization An error occurred: {str(e)}")
            self.logger.error(f"RAMUsageParser::processLinuxRamUtilization An error occurred: {str(e)}")
            raise

    def linuxLogExtractor(self, logFile):
        """
            Fetches RAM utilization data from a log file.

            Args:
            logFile (str): The path to the log file containing RAM utilization data.

            Returns:
            dict: A dictionary containing the RAM utilization details.

            Note:
            This function uses regular expressions to parse the log file and extract the RAM utilization data.
        """
        self.logger.info(f"RAMUsageParser::linuxLogExtractor Attempting to extract RAM utilization data from log file: {logFile}")
        logPattern1 = r'^(\d{2}:\d{2}:\d{2}),(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$'
        logPattern2 = r'^(\d{2}:\d{2}:\d{2}),(N/A),(-?\d+(?:\.\d+)?)$'
        try:
            with open(logFile, 'r') as file:
                # initialize an empty dictionary to store ram details
                ramDetails = {}
                self.logger.info("RAMUsageParser::linuxLogExtractor Log file opened successfully.")
                for line in file:
                    if (matchRamPattern := re.match(logPattern1, line) or re.match(logPattern2, line)):
                        ramDetails[matchRamPattern.group(1)] = [matchRamPattern.group(2), matchRamPattern.group(3)]
                if not ramDetails:
                    self.logger.error("RAMUsageParser::linuxLogExtractor Ram details are empty")
                    raise ValueError("RAM details are empty")
                return ramDetails
        except FileNotFoundError:
            self.logger.error(f"RAMUsageParser::linuxLogExtractor Error: File '{logFile}' not found.")
        except PermissionError:
            self.logger.error(f"RAMUsageParser::linuxLogExtractor Error: Permission denied to read file '{logFile}'.")
        except OSError as e:
            self.logger.error(f"RAMUsageParser::linuxLogExtractor Error: An OS error occurred while reading file '{logFile}': {e}")
        except Exception as e:
            self.logger.error(f"RAMUsageParser::linuxLogExtractor An unexpected error occurred: {e}")

    def run(self, osType, logFile, readConfig):
        print(f"Parsing {logFile}")
        if osType=='linux':
            threshold = 0
            try:
                threshold = float(readConfig['LINUX']['RAM']['threshold'])
                if(float(threshold) > 100 or float(threshold)<0):
                    self.logger.error(f"RAMUsageParser::run Please provide the proper threshold value in JSON!")
            except:
                print(f"Please provide the proper threshold value in JSON! \t Exiting gracefully...")
                sys.exit()

            topDetails = self.linuxLogExtractor(logFile)
            sets = self.processLinuxRamUtilization(topDetails)
            if self.avg<threshold:
                return [sets, topDetails, "PASS", threshold]
            else:
                return [sets, topDetails, "FAIL", threshold]
        elif osType=='qnx':
            self.logger.info(f"RAMUsageParser::run Processing QNX RAM usage details")
            pass