import os
import json
from parsers import parser_factory
from exporters import excel_exporter
from visualizers import graph_creator 
import threading
from pathlib import Path
import time

class UtilizationProcessor:
    """
    This class takes in the app request to process log extraction and report generation,
    gets the notification from main, process the parser and generates the report.
    """
    def __init__(self, logger, reportDir, configFile):
        self.logger = logger
        self.reportDir = reportDir
        self.configFile = configFile
        self.consumptionData = {}
        self.logger.info('UtilizationProcessor::__init__ Initializing UtilizationProcessor class.')

    def processReports(self):
        """
        Process reports based on the configuration file.
        """
        returnJson = {"PASS": 0, "FAIL": ""}
        try:
            with open(self.configFile, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            self.logger.error(f"UtilizationProcessor::processReports Configuration file {self.configFile} not found.")
            return {"PASS": 0, "FAIL": f"Configuration file {self.configFile} not found."}
        except json.JSONDecodeError:
            self.logger.error(f"UtilizationProcessor::processReports Invalid JSON in configuration file {self.configFile}.")
            return {"PASS": 0, "FAIL": f"Configuration file {self.configFile} not found."}

        returnJson = {}
        for folder in config['processedFolders']:
            logFiles = config['logFiles'][folder]
            if any(logFiles.values()):
                folderPath = os.path.join(self.reportDir, folder)
                self.logger.info(f"UtilizationProcessor::processReports Processing reports for Folder {folder}...")
                print(f"Parsing log file {[folder]}...")
                returnJson = self.processFolder(folder, logFiles)
            else:
                returnJson = {"PASS": 0, "FAIL": "No log files to Parse"}
        return returnJson

    def processFolder(self, folder, logFiles):
        """
        Process a single folder based on the log files configuration.
        """
        for osType, files in logFiles.items():
            if files != {}:
                    self.logger.info(f"UtilizationProcessor::processFolder Processing {osType} usage details")
                    self.consumptionData[osType] = [self.processFiles(folder, osType, files), files]      
        # pass whole consumption details in excel and graph class.
        for osType, files in logFiles.items():
            if files:
                excelExporter = excel_exporter.ExcelExporter(self.logger, self.reportDir, folder, self.consumptionData)
                # generateGraph = graph_creator.GraphCreator(self.logger, self.reportDir, folder, self.consumptionData)
                workBookPath, workSheet = excelExporter.run()
                # generateGraph.run()
                # excelExporter.addGraphToSheet(workBookPath, workSheet)

    def readConfigFile(self, file_path):
        """
        Load the KPI JSON configuration and return a nested dict that
        contains **only** the CPU, RAM and ROM information for each platform.
        """
        abs_path = os.path.abspath(os.path.expanduser(file_path))

        if not os.path.isfile(abs_path):
            raise FileNotFoundError(f"KPI config file not found: {abs_path}")

        with open(abs_path, 'r', encoding='utf-8') as f:
            raw = json.load(f)

        result = {}
        for platform, pdata in raw.items():
            if platform == "Units":
                # Keep the Units block unchanged (optional)
                result["Units"] = pdata
                continue

            result[platform] = {}
            for res in ("CPU", "RAM", "ROM"):
                block = pdata.get(res, {})

                # Find the key that ends with "_threshold" (e.g. kpi_cpu_threshold)
                thr_key = next((k for k in block if k.endswith("_threshold")), None)

                result[platform][res] = {
                    "threshold": block.get(thr_key, ""),
                    "interval":  block.get("interval", ""),
                    "delay":     block.get("delay", ""),
                }
        return result

    def processFiles(self, folder, osType, files):
        """
        Process files.
        """
        consumptionLinuxData = {}
        # parse kpi values and pass
        kpiFilePath = "../../configs/performanceConfig.json"
        readConfig = self.readConfigFile(kpiFilePath)
        fileTypes = ['cpu', 'ram', 'rom', 'stack']
        for fileType, fileName in files.items():
            if fileType in fileTypes:
                parser = parser_factory.ParserFactory.create_parser(fileType, self.logger)
                consumptionLinuxData[fileType] = parser.run(osType, fileName, readConfig)
                try:
                    # os.remove(fileName)
                    self.logger.warning(f"Deleted Log file: {fileName}")
                except Exception as E:
                    self.logger.warning(f"Error occured while deleting file: {fileName}")
            self.logger.info(f"Processed {osType} {fileType.capitalize()} file: {fileName}")      
        if bool(consumptionLinuxData):
            return consumptionLinuxData