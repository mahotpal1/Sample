#!/bin/bash

# ==========================
# CPU Monitoring Script
# ==========================

# Default values
DEFAULT_ITERATIONS=240
DEFAULT_DELAY=0.5
DEFAULT_PROCESS="N/A"
DEFAULT_OUTPUT="/tmp"

# Use environment variables or fallback defaults
iterations="${ITERATIONS:-$DEFAULT_ITERATIONS}"
delay="${DELAY:-$DEFAULT_DELAY}"
process_name="${MODE:-$DEFAULT_PROCESS}"
output_dir="${OUTDIR:-$DEFAULT_OUTPUT}"
top_command="top -b -d $delay -n $iterations -1"

# Ensure output directory exists
mkdir -p "$output_dir"

# Initialize output files
> "$output_dir/cpu_utilization.txt"
> "$output_dir/core_cpu_summary.txt"
# > "$output_dir/process_name_cpu.txt"

echo "[INFO] Monitoring CPU for $iterations iterations with $delay second(s) delay..."

if [ "$process_name" != "$DEFAULT_PROCESS" ]; then
    echo "[INFO] Tracking process: $process_name"
else
    echo "[INFO] Tracking system CPU only"
fi

echo "[INFO] Using command: $top_command"
# Run top and save output
eval "$top_command" >> "$output_dir/cpu_utilization.txt"

# =========================================
# Parse core-wise CPU usage with timestamps
# =========================================

while IFS= read -r line; do
    # Capture timestamp from 'top -' line
    if [[ $line =~ ^top\ -\ ([0-9]{2}:[0-9]{2}:[0-9]{2}) ]]; then
        timestamp="${BASH_REMATCH[1]}"
        echo "Timestamp: $timestamp" >> "$output_dir/core_cpu_summary.txt"
        continue
    fi
    # Process %Cpu lines (may contain multiple cores per line)
    if [[ $line =~ %Cpu ]]; then
        IFS='%Cpu' read -ra cores <<< "$line"
        for core_info in "${cores[@]}"; do
            [[ -z "$core_info" ]] && continue
            # Extract CPU number
            if [[ $core_info =~ ^([0-9]+) ]]; then
                cpu_id="${BASH_REMATCH[1]}"
            fi
            # Extract idle percentage and calculate usage
            if [[ $core_info =~ ([0-9.]+)[[:space:]]+id ]]; then
                idle="${BASH_REMATCH[1]}"
                usage=$(awk -v idle="$idle" 'BEGIN{printf "%.2f", idle}')
                echo "CPU$cpu_id: $usage%" >> "$output_dir/core_cpu_summary.txt"
            fi
        done
    fi
    # Capture CPU usage of the 'top' command itself (exact match)
    # Split line into fields
    fields=($line)
    # Skip if line has less than 12 fields (not a process line)
    if (( ${#fields[@]} >= 12 )); then
        command="${fields[-1]}"       # Last column is COMMAND
        cpu_val="${fields[8]}"        # 9th column is %CPU (0-based index 8)
        # Only capture if command is exactly 'top' and cpu_val is numeric
        if [[ "$command" == "top" ]] && [[ $cpu_val =~ ^[0-9.]+$ ]]; then
            echo "Top command CPU usage: $cpu_val%" >> "$output_dir/core_cpu_summary.txt"
        fi
    fi
    echo "-----------------------------------------------------------------"
done < "$output_dir/cpu_utilization.txt"

# =========================================
# Process-specific CPU tracking (if specified)   // To see later
# =========================================

# if [ "$process_name" != "$DEFAULT_PROCESS" ]; then
#     grep -w "$process_name" "$output_dir/cpu_utilization.txt" | awk '{sum += $9} END {print strftime("%T"), sum}' >> "$output_dir/process_name_cpu.txt"
# fi

echo "[INFO] CPU monitoring complete. Logs saved to $output_dir"
 