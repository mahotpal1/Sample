import json
import logging
import argparse
from pydlt import DltFileReader
import datetime
import pandas as pd
import matplotlib.pyplot as plt
import os
import traceback
import textwrap
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font

def setup_logger(log_path):
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[logging.FileHandler(log_path, mode='w'), logging.StreamHandler()]
    )
    logging.getLogger('matplotlib').setLevel(logging.WARNING)

def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def extract_dlt_logs(dlt_path, limit=None):
    logs = []
    for i, msg in enumerate(DltFileReader(dlt_path)):
        if limit and i >= limit:
            break
        logs.append({
            'Index': i,
            'Time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'Timestamp': getattr(msg, 'timestamp', ''),
            'Ecuid': getattr(msg, 'ecuid', ''),
            'Apid': getattr(msg, 'apid', ''),
            'Ctid': getattr(msg, 'ctid', ''),
            'Type': getattr(msg, 'type', ''),
            'Payload': str(getattr(msg, 'payload', msg)),
            'Status': 'Not required'
        })
    return logs

def validate_logs(expected_logs, actual_logs):
    found = set()
    for entry in actual_logs:
        for log in expected_logs:
            if log in entry['Payload']:
                entry['Status'] = 'PASS'
                found.add(log)
                break
    for missing in set(expected_logs) - found:
        actual_logs.append({
            'Index': '-',
            'Time': '-',
            'Timestamp': '-',
            'Ecuid': '-',
            'Apid': '-',
            'Ctid': '-',
            'Type': '-',
            'Payload': missing,
            'Status': 'FAIL'
        })
    return actual_logs

def save_table_as_image(df, output_path, max_rows=300):
    df = df.head(max_rows)
    fig_height = 2.5 * len(df)
    plt.rcParams['font.family'] = 'DejaVu Sans'
    fig, ax = plt.subplots(figsize=(25, fig_height))
    ax.axis('off')

    cell_text = df.values.tolist()
    wrapped_labels = [textwrap.fill(label, width=15) for label in df.columns]
    col_labels = wrapped_labels

    min_width = 1
    max_lengths = []
    for col in df.columns:
        col_data = [str(item) if pd.notna(item) else '' for item in df[col]]
        filtered_data = [item for item in col_data if item.strip() != '']
        max_data_length = max((len(item) for item in filtered_data), default=0)
        header_length = len(col)
        max_len = max(max_data_length, header_length, min_width)
        max_lengths.append(max_len)

    total = sum(max_lengths)
    col_widths = [max_len / total for max_len in max_lengths]

    row_colors = []
    for status in df['Status']:
        if status == 'PASS':
            row_colors.append(['#d4f7d4'] * len(df.columns))
        elif status == 'FAIL':
            row_colors.append(['#f8d6d6'] * len(df.columns))
        else:
            row_colors.append(['white'] * len(df.columns))

    table = ax.table(
        cellText=cell_text,
        colLabels=col_labels,
        colWidths=col_widths,
        loc='center',
        cellLoc='left',
        cellColours=row_colors
    )

    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1.1, 1.3)

    for j in range(len(df.columns)):
        header_cell = table[0, j]
        header_cell._text.set_wrap(True)
        header_cell._text.set_fontsize(8)
        header_cell.set_height(0.05)

    for i in range(len(df)):
        for j in range(len(df.columns)):
            cell = table[i + 1, j]
            cell.set_height(0.05)
            cell._text.set_wrap(True)

    plt.savefig(output_path, bbox_inches='tight', dpi=300)

def save_table_as_excel(df, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "DLT Validation"

    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
        ws.append(row)
        if r_idx == 1:
            for cell in ws[r_idx]:
                cell.font = Font(bold=True)

    for col in ws.columns:
        max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in col)
        adjusted_width = max_length + 2
        ws.column_dimensions[col[0].column_letter].width = adjusted_width

    wb.save(output_path)

def run_validation(app_name, config, sample_limit=None, result_dir="../../results"):
    details = config[app_name]
    dlt_path = details["LogFile"]
    expected_logs = details["LogsToBeVerified"]
    timestamp_str = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

    try:
        logging.info(f"[{app_name}] Starting validation...")
        actual_logs = extract_dlt_logs(dlt_path, limit=sample_limit)
        validated = validate_logs(expected_logs, actual_logs)

        df = pd.DataFrame(validated)
        df.drop_duplicates(subset=['Payload', 'Status'], keep='last', inplace=True)

        app_result_dir = os.path.join(result_dir, f"{app_name}_{timestamp_str}_dlt_validation")
        os.makedirs(app_result_dir, exist_ok=True)

        excel_path = os.path.join(app_result_dir, f"{app_name}_{timestamp_str}.xlsx")
        save_table_as_excel(df, excel_path)
        logging.info(f"[{app_name}] Saved Excel at {excel_path}")

        filtered_df = df[df['Status'].isin(['PASS', 'FAIL'])].copy()
        png_path = os.path.join(app_result_dir, f"{app_name}_{timestamp_str}.png")
        save_table_as_image(filtered_df, png_path)
        logging.info(f"[{app_name}] Saved PNG snapshot at {png_path}")

        failed = df[df['Status'] == 'FAIL']['Payload'].tolist()
        passed = df[df['Status'] == 'PASS'].shape[0]

        result_json = {
            app_name: {
                "PASS": passed,
                "FAIL": failed
            }
        }

        #logging.info(f"[{app_name}] Validation result: {json.dumps(result_json, indent=2)}")
        return result_json

    except Exception as e:
        logging.error(f"[{app_name}] Error during validation: {e}")
        logging.debug(traceback.format_exc())
        return {
            app_name: {
                "PASS": 0,
                "FAIL": [f"Validation failed due to error: {str(e)}"]
            }
        }

def main():
    parser = argparse.ArgumentParser(description="DLT Log Validator - App-Based Validation")
    parser.add_argument('--app', type=str, required=True, help="Comma-separated list of app names (e.g., app1,app2)")
    parser.add_argument('--dltpath', type=str, required=True, help="Path to DLT log file")
    parser.add_argument('--resultPath', type=str, required=True, help="Directory to save result files")
    parser.add_argument('--config', default='../../configs/dltConfig.json', help="Path to config file")
    parser.add_argument('--sample', type=int, help="Limit number of DLT messages to process")
    args = parser.parse_args()

    setup_logger("../../logs/dlt_validation_debug.log")
    config = load_config(args.config)

    apps_requested = [app.strip() for app in args.app.split(',')]
    all_results = {}

    for app_name in apps_requested:
        if app_name not in config:
            logging.warning(f"App '{app_name}' not found in config, skipping.")
            continue

        config[app_name]["LogFile"] = args.dltpath
        result = run_validation(app_name, config, sample_limit=args.sample, result_dir=args.resultPath)
        all_results[app_name] = {
            "PASS": result[app_name]["PASS"],
            "FAIL": result[app_name]["FAIL"]
        }

    return all_results
    #print(json.dumps(all_results, indent=2))

if __name__ == "__main__":
    all_results = main()

    #print(json.dumps(all_results, indent=2))
    print(json.dumps(all_results)) #if we put indent and print the pyserver won't be able to read
