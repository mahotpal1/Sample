import re
from datetime import date
import threading 
import time
import sys

class ROMUsageParser:
    """
        This class takes in ROM usage data, extracts and processes the relevant details
    """

    def __init__(self, logger):
        self.logger = logger
        self.avg=0
        self.logger.info("ROMUsageParser instance created.")

    def processLinuxRomUtilization(self, romDetails):
        """
        Processes the Rom details for report and graph generation.

        Args:
        romDetails (dict): A dictionary containing the rom utilization details.

        Returns:
        dict: A dictionary containing the average, maximum, and minimum utilization.
        """
        try:
            self.logger.info("ROMUsageParser::processLinuxRomUtilization Processing results...")
            # Handle cases if dictionary is empty
            if not romDetails:
                self.logger.error("ROMUsageParser::processLinuxRomUtilization topDetails is empty")
                return {}

            # Extract utilization values
            utilizations = [int(value) for value in romDetails.values()]

            # Calculate min, max, and average
            min_utilization = min(utilizations)
            max_utilization = max(utilizations)
            avg_utilization = int(sum(utilizations) / len(utilizations))

            results = {
                'min': min_utilization,
                'max': max_utilization,
                'avg': avg_utilization
            }

            self.avg = avg_utilization  # Store the average for potential other uses
            return results

        except Exception as e:
            print(f"ROMUsageParser::processLinuxRomUtilization An error occurred: {str(e)}")
            self.logger.error(f"ROMUsageParser::processLinuxRomUtilization An error occurred: {str(e)}")
            raise

    def linuxLogExtractor(self, logFile):
        """
            Fetches ROM utilization data from a log file.

            Args:
            logFile (str): The path to the log file containing ROM utilization data.

            Returns:
            dict: A dictionary containing the ROM utilization details.

            Note:
            This function uses regular expressions to parse the log file and extract the ROM utilization data.
        """
        self.logger.info(f"ROMUsageParser::linuxLogExtractor Attempting to extract ROM utilization data from log file: {logFile}")
        logPattern1 = r"^(\d{2}:\d{2}:\d{2}),(\d+)MB\/(\d+)MB,(\d+)%$"
        logPattern2 = r'^(\d{2}:\d{2}:\d{2}),(N/A),(\d+)%$'
        try:
            with open(logFile, 'r') as file:
                # initialize an empty dictionary to store rom details
                romDetails = {}
                self.logger.info("ROMUsageParser::linuxLogExtractor Log file opened successfully.")
                for line in file:
                    if (matchRomPattern := re.match(logPattern1, line) or re.match(logPattern2, line)):
                        romDetails[matchRomPattern.group(1)] = matchRomPattern.group(4)
                if not romDetails:
                    self.logger.error("ROMUsageParser::linuxLogExtractor Rom details are empty")
                    raise ValueError("ROM details are empty")
                return romDetails
        except FileNotFoundError:
            self.logger.error(f"ROMUsageParser::linuxLogExtractor Error: File '{logFile}' not found.")
        except PermissionError:
            self.logger.error(f"ROMUsageParser::linuxLogExtractor Error: Permission denied to read file '{logFile}'.")
        except OSError as e:
            self.logger.error(f"ROMUsageParser::linuxLogExtractor Error: An OS error occurred while reading file '{logFile}': {e}")
        except Exception as e:
            self.logger.error(f"ROMUsageParser::linuxLogExtractor An unexpected error occurred: {e}")

    def run(self, osType, logFile, readConfig):
        print(f"Parsing {logFile}")
        if osType=='linux':
            topDetails = self.linuxLogExtractor(logFile)
            try:
                threshold = float(readConfig['LINUX']['ROM']['threshold'])
                if(float(threshold) > 100 or float(threshold)<0):
                    self.logger.error(f"ROMUsageParser::run Please provide the proper threshold value in JSON!")
            except:
                print(f"Please provide the proper threshold value in JSON! \t Exiting gracefully...")
                sys.exit()

            sets = self.processLinuxRomUtilization(topDetails)
            if self.avg<threshold:
                return [sets, topDetails, "PASS", threshold]
            else:
                return [sets, topDetails, "FAIL", threshold]
        elif osType=='qnx':
            self.logger.info(f"ROMUsageParser::run Processing QNX ROM usage details")
            pass