import logging
import os
from datetime import datetime
from enum import Enum
        
class LoggerSingleton:
    """
    A singleton class for logging that provides a single instance of the logger throughout the application.
    This class initializes the logger with a file handler and sets the logging level to INFO.
    """
    # Initialize the instance variable to None
    _instance = None

    def __new__(cls):
        try:
            # Check if an instance already exists
            if cls._instance is None:
                # Create a new instance
                cls._instance = super(LoggerSingleton, cls).__new__(cls)
            # Return the existing or newly created instance
            return cls._instance
        except Exception as e:
            print(f"Error creating LoggerSingleton instance: {str(e)}")
            return None

    # returns respective log level
    def getLogLevel(self, logLevel):
        if logLevel=='logging.INFO':
            return logging.INFO
        elif logLevel=='logging.ERROR':
            return logging.ERROR
        elif logLevel=='logging.WARNING':
            return logging.WARNING
        elif logLevel=='logging.ERROR':
            return logging.ERROR
        elif logLevel=='logging.CRITICAL':
            return logging.CRITICAL

    # Initialize the logger with the required settings
    def initLogger(self, logFileLocation, logLevel):
        try:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.INFO)

            currentTimestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            try:
                logLevel=self.getLogLevel(logLevel)
            except AttributeError:
                print(f"Invalid log level string: {logLevel}")
                logLevel = logging.CRITICAL
            # Create a file handler
            if not os.path.exists(logFileLocation):
                os.makedirs(logFileLocation)
            file_handler = logging.FileHandler(os.path.join(logFileLocation, f'{currentTimestamp}.log'))
            file_handler.setLevel(logLevel)

            # Create a formatter and add it to the handlers
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)

            # Add the handlers to the logger
            self.logger.addHandler(file_handler)
        except FileNotFoundError:
            print(f"Error: Log file location '{logFileLocation}' does not exist.")
        except PermissionError:
            print(f"Error: Permission denied to create log file at '{logFileLocation}'.")
        except Exception as e:
            print(f"Error initializing logger: {str(e)}")

    def getLogger(self, logFileLocation, logLevel):
        try:
            if not hasattr(self, 'logger') or self.logger.handlers[0].baseFilename != os.path.join(logFileLocation, f'{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}.log'):
                self.initLogger(logFileLocation, logLevel)
            # Return the logger instance
            return self.logger
        except AttributeError:
            print("Error: Logger instance not initialized.")
            return None
        except Exception as e:
            print(f"Error getting logger instance: {str(e)}")
            return None