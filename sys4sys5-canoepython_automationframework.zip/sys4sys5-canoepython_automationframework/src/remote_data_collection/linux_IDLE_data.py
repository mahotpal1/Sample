import paramiko
import threading
import sys
import os
import time
import stat
import logging
import json
from scp import SCPClient
from datetime import datetime
import argparse
from pathlib import Path

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'py_receiver'))) 
from flagManager import FlagManager

executed_tasks = []
runtime_testID = None
runtime_mode = None
logLevel = FlagManager.read_log_level()

# returns respective log level
def getLogLevel(logLevel):
    if logLevel=='logging.INFO':
        return logging.INFO
    elif logLevel=='logging.ERROR':
        return logging.ERROR
    elif logLevel=='logging.WARNING':
        return logging.WARNING
    elif logLevel=='logging.DEBUG':
        return logging.ERROR
    elif logLevel=='logging.CRITICAL':
        return logging.CRITICAL


def load_config(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"[CONFIG] File not found: {path}", exc_info=True)
    except json.JSONDecodeError as e:
        logging.error(f"[CONFIG] JSON parsing failed in '{path}': {e}", exc_info=True)
    except Exception as e:
        logging.error(f"[CONFIG] Unexpected error loading '{path}': {e}", exc_info=True)
    return None

def setup_logging():
    try:
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(result_dir, exist_ok=True)
        logging.basicConfig(
            level=getLogLevel(logLevel),
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[
                logging.FileHandler(os.path.join(log_dir, "daemon.log")),
                logging.StreamHandler()
            ]
        )
    except Exception as e:
        print(f"[ERROR] Failed to set up logging: {e}")
        exit(1)

def get_host_logger(ipAddress, operatingSystem):
    try:
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        #log_path = os.path.join(log_dir, f"{ipAddress.replace('.', '_')}.log")
        log_path = os.path.join(log_dir, f"{operatingSystem}_{args.app}_{args.usecase}_{timestamp}.log")
        logger = logging.getLogger(ipAddress)
        logger.setLevel(getLogLevel(logLevel))
        if not logger.handlers:
            handler = logging.FileHandler(log_path)
            handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
            logger.addHandler(handler)
        return logger
    except Exception as e:
        logging.error(f"[LOGGER] Failed to create logger for {ipAddress}: {e}", exc_info=True)
        return logging.getLogger("default")


def get_r(sftp, remote_dir, local_dir):
    """
    Recursively download remote_dir from SFTP server to local_dir.
    """
    try:
        os.makedirs(local_dir, exist_ok=True)
        for item in sftp.listdir_attr(remote_dir):
            remote_path = f"{remote_dir}/{item.filename}"
            local_path = os.path.join(local_dir, item.filename)

            if stat.S_ISDIR(item.st_mode):
                get_r(sftp, remote_path, local_path)
            else:
                sftp.get(remote_path, local_path)
    except Exception as e:
        logging.error(f"[SFTP] Failed to download from {remote_dir}: {e}", exc_info=True)

def run_remote_operations(ipAddress, operatingSystem, username, password, script_path, local_host_dir, duration, delay, mode):
    host_logger = get_host_logger(ipAddress, operatingSystem)
    try:
        with open(script_path, "r") as f:
            script_content = f.read()

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ipAddress, username=username, password=password)

        output_dir = f"/tmp/{test_id}_output_{ipAddress.replace('.', '_')}_{mode}"
        host_logger.info(f"[{mode}] Starting execution of {script_path}")
        print(f"[START] Host: {ipAddress}, Script: {os.path.basename(script_path)}, Mode: {mode}")

        remote_command = f"""
            export ITERATIONS={duration}
            export DELAY={delay}
            export MODE={mode}
            export OUTDIR={output_dir}
            export TERM=xterm;
            export COLUMNS=200;
            mkdir -p $OUTDIR;
            bash -s > /tmp/script_output.log 2>&1;
            wait;
        """

        stdin, stdout, stderr = ssh.exec_command(remote_command)
        stdin.write(script_content)
        stdin.channel.shutdown_write()

        exit_status = stdout.channel.recv_exit_status()
        host_logger.info(f"[{mode}] Script exit status: {exit_status}")
        print(f"[DONE] Host: {ipAddress}, Mode: {mode}, Exit: {exit_status}")

        local_test_dir = os.path.join(local_host_dir, mode)
        os.makedirs(local_test_dir, exist_ok=True)

        # Open SFTP session
        sftp = ssh.open_sftp()

        stdin, stdout, stderr = ssh.exec_command(f"ls -l {output_dir}")
        host_logger.info(f"[{mode}] Output contents:\n{stdout.read().decode()}")

        stdin, stdout, stderr = ssh.exec_command(f"test -d {output_dir} && echo 'exists'")
        if stdout.read().decode().strip() == "exists":
            get_r(sftp, output_dir, local_test_dir)
            host_logger.info(f"[{mode}] Output copied.")
        else:
            host_logger.warning(f"[{mode}] Output directory not found.")

        ssh.exec_command(f"rm -rf {output_dir} /tmp/script_output.log")
        sftp.close()
        ssh.close()

    except Exception as e:
        host_logger.error(f"[{mode}] Exception: {e}", exc_info=True)
        print(f"[ERROR] Host: {ipAddress}, Mode: {mode}, Error: {e}")


def start_processing(application = None):
    try:
        test_dir_name = f"{test_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        test_raw_path = Path(result_dir) / test_dir_name
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        duration = "10" #iteration
        delay = "0.5" #delay
        thread_list = []
        count = 0

        test_raw_path.mkdir(parents=True, exist_ok=True)

        for host in hosts:
            ipAddress = host["ipAddress"]
            username = host["username"]
            password = host["password"]
            operatingSystem = host["operatingSystem"]
            operatingSystem = operatingSystem + "_idle"
            local_host_dir = test_raw_path / operatingSystem
            local_host_dir.mkdir(parents=True, exist_ok=True)

            # Start threads for each script
            for script in host["scripts"]:
                script_name = script["name"]

                #flexibility for later socket connection
                mode = runtime_mode or script.get("mode", "generic")
                script_path = f"../../shell_scripts/{script_name}"

                thread = threading.Thread(
                    target=run_remote_operations,
                    args=(ipAddress, operatingSystem, username, password, script_path, local_host_dir, duration, delay, mode)
                )
                thread_list.append(thread)
                thread.start()
                executed_tasks.append((ipAddress, script_name, mode))
                logging.info(f"[THREAD] Started: {script_name} on {ipAddress} for mode={mode}")

        for thread in thread_list:
            thread.join()

    except Exception as e:
        logging.critical(f"[PROCESSING] Fatal error during execution: {e}", exc_info=True)
        print(f"[FATAL] Error during processing: {e}")
        return {
            "TestRawPath": None,
            "Error": str(e)
        }

    TR = {
            "TestRawPath": str(test_raw_path.resolve())
    }
    logging.info(f"Result : {str(TR)}")
    
    return TR

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Inputs given to remote file")
    parser.add_argument("--app", default="FDR", help="Application name for filtering")
    parser.add_argument("--usecase", default="First001", help="Usecase for the given Test")

    args = parser.parse_args()
    runtime_testID = args.usecase

    config = load_config("../../configs/environmentConfig.json")
    if config is None:
        logging.critical("[CONFIG] Cannot continue without valid configuration.")
        exit(1)

    global_config = config["global_config"]
    hosts = config["hosts"]

    log_dir = global_config["log_dir"]
    result_dir = global_config["result_dir"]
    tcpdump_duration = global_config["tcpdump_duration"]

    #flexibility for Socket connection
    test_id = runtime_testID or global_config["test_id"]

    setup_logging()
    logging.info(f"[MAIN] Processing started for application {args.app}") 

    result = start_processing(args.app)

    print(json.dumps(result))
