import os
import json
from datetime import datetime

class JsonHandler:
    """
    A class used to handle JSON file operations.
    """

    def __init__(self, filePath):
        """
        Initialize the JsonHandler class.

        Args:
        filePath (str): Path to the JSON file.
        """
        self.filePath = filePath

    def readJson(self):
        """
        Read the JSON data from the file.

        Returns:
        dict: The JSON data.
        """
        try:
            with open(self.filePath, 'r') as file:
                data = json.load(file)
                if not data:
                    # If the JSON file is empty, create an empty dictionary
                    data = {
                        'processedFolders': [],
                        'logFiles': {}
                    }
                return data
        except FileNotFoundError:
            # If the JSON file does not exist, create an empty dictionary
            return {
                'processedFolders': [],
                'logFiles': {}
            }
        except json.JSONDecodeError:
            # If the JSON file is empty or contains invalid JSON, create an empty dictionary
            return {
                'processedFolders': [],
                'logFiles': {}
            }

    def writeJson(self, data):
        """
        Write the JSON data to the file.

        Args:
        data (dict): The JSON data.

        Returns:
        None
        """
        try:
            with open(self.filePath, 'w') as file:
                json.dump(data, file, indent=4)
        except Exception as e:
            raise Exception(f"Failed to write JSON data: {str(e)}")

    def updateJson(self, data):
        """
        Update the JSON data in the file.

        Args:
        data (dict): The updated JSON data.

        Returns:
        None
        """
        self.writeJson(data)