import datetime
import os
 
class Timer:
    @staticmethod
    def createTimeStamp():
        """Initializes the timestamp if not already set in constants.py."""
        try:
            import constants
            import importlib

            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            Timer._update_or_add_timestamp(timestamp)

            # Reload the constants module to reflect the updated timestamp
            importlib.reload(constants)
            print(f"Timestamp created: {timestamp}")

        except Exception as e:
            print(f"Error while creating timestamp: {e}")


    @staticmethod
    def getTimeStamp():
        """Returns the timestamp from constants.py."""
        try:
            import constants

            if getattr(constants, 'generatedTimeStamp', '') == '':
                raise ValueError("Timestamp has not been created yet. Call createTimeStamp first.")
            return constants.generatedTimeStamp
        except Exception as e:
            print(f"Error while retrieving timestamp: {e}")
            return None

    @staticmethod
    def _update_or_add_timestamp(timestamp):
        """Updates or adds the generatedTimeStamp variable in constants.py without disturbing other content."""
        try:
            file_path = "constants.py"
            if not os.path.exists(file_path):
                with open(file_path, "w") as f:
                    f.write(f"generatedTimeStamp = '{timestamp}'\n")
                return

            with open(file_path, "r") as f:
                lines = f.readlines()

            updated = False
            for i, line in enumerate(lines):
                if line.strip().startswith("generatedTimeStamp"):
                    lines[i] = f"generatedTimeStamp = '{timestamp}'\n"
                    updated = True
                    break

            if not updated:
                lines.append(f"generatedTimeStamp = '{timestamp}'\n")

            with open(file_path, "w") as f:
                f.writelines(lines)

        except Exception as e:
            print(f"Error occurred during timestamp value update: {e}")
