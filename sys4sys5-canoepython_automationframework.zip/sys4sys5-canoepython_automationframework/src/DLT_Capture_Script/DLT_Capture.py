import datetime
import logging
import os
import subprocess
import sys
import yaml
import xml.etree.ElementTree as ET
from pathlib import Path
import argparse

logger = logging.getLogger(__name__)

# --- Configuration ---
yaml_file_path = '../DLT_Capture_Script/ECU_config.yml'  # Replace with your actual path

def read_yaml_data(file_path):
    """Loads a YAML file and returns the data as a Python dictionary."""
    try:
        with open(file_path, 'r') as file:
            data = yaml.safe_load(file)
        print(f"YAML data loaded successfully from: {file_path}")
        return data
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        logger.error(f"File not found at {file_path}")
        return None
    except yaml.YAMLError as e:
        print(f"Error parsing YAML: {e}")
        logger.error(f"Error parsing YAML: {e}")
        return None

def capture_logs_from_dlt_viewer(log_file_name, dlt_file_name, project_file_name, config):
    """Captures diagnostic logs from ECU using DLT viewer."""
    timeout = config['DLTViewerLogCaptureTime']
    ecu_type = config['ecu-type']
    print("capture_logs_from_dlt_viewer :: START")
    print(f"Capturing logs with timeout: {timeout} seconds")
    script_dir = Path(__file__).parent.joinpath("dlt-viewer.bat")

    if sys.platform.startswith("win"):
        dlt_viewer_path = config['dltViewerPath']
        log_file_name = os.path.join(log_file_name)
        logger.info(f"dlt_viewer_path: {dlt_viewer_path}")
        logger.info(f"log_file_name : {log_file_name}")
        subprocess.call([script_dir, dlt_viewer_path, str(timeout), log_file_name, dlt_file_name, project_file_name])
    elif sys.platform.startswith("linux"):
        subprocess.run("timeout " + str(timeout) + " dlt-viewer -p "+project_file_name+" -l "+dlt_file_name+" -v", shell=True)
        print("Converting *.dlt to *.log...")
        subprocess.run(f"dlt-viewer -c {dlt_file_name}" + str(log_file_name), shell=True)
        print("Conversion done, successfully...")

    size = os.path.getsize(log_file_name)
    if size == 0:
        logger.warning(f"Generated {os.path.basename(log_file_name)} is empty, Please check for valid IP-address / Status of {ecu_type}.")
        return False
    return True


def create_dlp_files(config):
    # Directly access the values from the config
    ecu_type = config['ecu-type']
    ip_address = config['ip-address']
    ip_port = config['ip-port']
    dlt_viewer_log_capture_time = config['DLTViewerLogCaptureTime']
    print(f"ECU Type: {ecu_type}, IP Address: {ip_address}")

    output_dir = 'DLP'
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir_path = os.path.join(script_dir, output_dir)
    dlp_files = {}
    # Create output directory if it doesn't exist or clear it if it does
    if os.path.exists(output_dir_path):
        # Clear all files in the directory
        for file in os.listdir(output_dir_path):
            file_path = os.path.join(output_dir_path, file)
            if os.path.isfile(file_path):
                os.unlink(file_path)
    else:
        os.makedirs(output_dir_path)
    # Use the script directory to find the proj.dlp file
    proj_path = os.path.join(script_dir, 'proj.dlp')
    tree = ET.parse(proj_path)
    root = tree.getroot()
    project_name = f"{ecu_type}.dlp"
    # Set hostname text to the IP address
    hostname = root.find('ecu/hostname')
    if hostname is not None:
        hostname.text = ip_address
    else:
        print(f"Warning: 'hostname' not found for ECU {ecu_type}")

    # Set ipport text to the IP address
    ipport = root.find('ecu/ipport')
    if ipport is not None:
        ipport.text = ip_port
    else:
        print(f"Warning: 'IPPort' not found for ECU {ecu_type}")
    # Write updated XML to file
    output_path = os.path.join(output_dir_path, project_name)
    dlp_files = output_path
    tree.write(output_path, encoding='utf-8', xml_declaration=True)
   
    return dlp_files

def main():
    """Main function to run the script."""
    
    parser = argparse.ArgumentParser(description="DLT Capture Script")
    parser.add_argument("--resultPath",required=True, type=str, help="Path to store the results")
    args = parser.parse_args()

    global yaml_file_path
    if not args.resultPath:
        print("[DLT Capture]: argument not provided, exiting..")
        sys.exit()
        
    yaml_file_path ='../DLT_Capture_Script/ECU_config.yml'
    
    config = read_yaml_data(yaml_file_path)
    if not config:
        print("Failed to load YAML configuration. Exiting.")
        return
    # Directly access the values from the config
    ecu_type = config['ecu-type']
    current_timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    logfile = f"{current_timestamp}_DLT_Logs_{ecu_type}.log"

    dltfile = os.path.join(args.resultPath, f"DLT_Log.dlt")
    
    dlp_file = create_dlp_files(config)
    capture_logs_from_dlt_viewer(logfile, dltfile, dlp_file, config)

if __name__ == "__main__":
    main()  # Call the main function