import os
import json
from datetime import datetime
from utils import json_handler

class LogProcessor:
    def __init__(self, configFile, resultFolder, loggerInst, args=None):
        """
        Initialize the LogProcessor class.

        Args:
        configFile (str): Path to the configuration file.
        resultFolder (str): Path to the result folder.
        loggerInst: logger Instance
        """
        self.configFile = configFile
        self.resultFolder = resultFolder
        self.loggerInst = loggerInst
        self.jsonHandler = json_handler.JsonHandler(configFile)
        self.args = args
        self.loggerInst.info("Initializing LogProcessor class")
    
    def processLogs(self):
        """
        Process the log files in the result folder.

        Returns:
        Json with success or failure
        """
        self.loggerInst.info("LogProcessor::processLogs Processing log files in result folder")
        configData = {}
        
        self.loggerInst.info("LogProcessor::processLogs Loaded configuration:")
        self.loggerInst.debug(json.dumps(configData, indent=4))
        # store the passed parameters
        folderName = self.args.logsDir
        osType = self.args.osType
        perfParam = self.args.perfParam.split(',')

        if osType not in ['linux', 'qnx']:
            self.loggerInst.warning(f"LogProcessor::processLogs Invalid OS Type: {osType}")
            print(f"Invalid OS Type: {osType}")
            return {"PASS":0, "FAIL": f"Invalid OS Type: {osType}"}
        
        folderNamePath = os.path.join(self.resultFolder, folderName)
        if not os.path.isdir(folderNamePath):
            self.loggerInst.error(f"Invalid Folder Name {folderName}")
            print(f"Invalid Folder Name {folderName}")
            return {"PASS":0, "FAIL": f"Invalid Folder Name {folderName}"}

        logFolderPath = os.path.join(folderNamePath, osType)

        # Check if the log folder is a directory
        if os.path.isdir(logFolderPath):
            self.loggerInst.info(f"LogProcessor::processLogs Found folder {logFolderPath}")
            # Get the log files for the log folder as per the kpi provided
            logFiles = self.getLogFiles(logFolderPath, osType, perfParam)
            if "FAIL" in logFiles:
                return {"PASS": 0, "FAIL": logFiles["FAIL"]}
            else:
                self.loggerInst.debug(f"Log files for {folderName}: {json.dumps(logFiles, indent=4)}")

            # Update the configuration with the new log files
            configData = self.updateConfig(configData, folderName, logFiles)

            # Clear existing values
            configData['processedFolders'] = [folderName]
            configData['logFiles'] = {folderName: logFiles}
        else:
            self.loggerInst.error(f"LogProcessor::processLogs Log folder {folderName} not found")
            return {"PASS": 0, "FAIL": (f"LogProcessor::processLogs Log folder {folderName} not found")}
        # Save the updated configuration
        self.saveConfig(configData)
        self.loggerInst.info("LogProcessor::processLogs Updated configuration:")
        self.loggerInst.debug(json.dumps(configData, indent=4))
        return {"PASS": 1, "FAIL": ""}

    def loadConfig(self):
        """
        Load the configuration from the config file.

        Returns:
        dict: The configuration data.
        """
        self.loggerInst.info("LogProcessor::loadConfig Loading configuration from config file")
        configData = self.jsonHandler.readJson()
        self.loggerInst.info("LogProcessor::loadConfig Loaded configuration successfully")
        return configData

    def getLogFiles(self, logFolderPath, osType, perfParam):
        """
        Get the log files for a given log folder.

        Args:
        logFolderPath (str): Path to the log folder.

        Returns:
        dict: The log files for the respective os log folder.
        """
        self.loggerInst.info(f"LogProcessor::getLogFiles Getting log files for {logFolderPath} :: {perfParam}")
        logFiles = {osType:{}}
        val = ""
        foldersInPath = os.listdir(logFolderPath)
        for i in perfParam:
            if (i == 'CPU'):
                if 'cpu' not in foldersInPath:
                    self.loggerInst.warning(f"LogProcessor::getLogFiles Cpu log files not present for provided folder!!")
                    return {"PASS":0, "FAIL": "LogProcessor::getLogFiles Cpu logs not present"}
            elif i in ["RAM", "ROM", "STACK"]:
                if 'ram_rom' not in foldersInPath:
                    self.loggerInst.warning(f"LogProcessor::getLogFiles RAM/ROM/STACK log files not present for provided folder!!")
                    return {"PASS":0, "FAIL": "LogProcessor::getLogFiles RAM/ROM/STACK logs not present"}
        if (perfParam == ['ALL']):
            for folder in foldersInPath:
                eachFolderPath = os.path.join(logFolderPath, folder)
                for file in os.listdir(eachFolderPath):
                    if folder=='ram_rom':
                        if file.endswith("rom_usage_linux.txt"):
                            logFiles[osType]['rom'] = os.path.join(eachFolderPath, file)
                        elif file.endswith("stack_usage_linux.txt"):
                            logFiles[osType]['stack'] = os.path.join(eachFolderPath, file)
                        elif file.endswith("ram_usage_linux.txt"):
                            logFiles[osType]['ram'] = os.path.join(eachFolderPath, file)
                        elif file.endswith("mem_details_linux.txt"):
                            logFiles[osType]['mem_details_linux'] = os.path.join(eachFolderPath, file)
                    elif folder=='cpu':
                        if file.endswith("core_cpu_summary.txt"):
                            logFiles[osType]['cpu'] = os.path.join(eachFolderPath, file)
                        elif file.endswith("cpu_utilization.txt"):
                            logFiles[osType]['cpu_util'] = os.path.join(eachFolderPath, file)
        else:
            found=False
            for i in range(0, len(perfParam)):
                if perfParam[i] == 'RAM':
                    listDir = os.listdir(os.path.join(logFolderPath, 'ram_rom'))
                    for log in listDir:
                        if log.endswith("ram_usage_linux.txt"):
                            logFiles[osType]['ram'] = os.path.join(logFolderPath, 'ram_rom', log)
                        elif log.endswith("mem_details_linux.txt"):
                            logFiles[osType]['mem_details_linux'] = os.path.join(logFolderPath, 'ram_rom', log)
                elif perfParam[i] == 'ROM':
                    listDir = os.listdir(os.path.join(logFolderPath, 'ram_rom'))
                    for log in listDir:
                        if log.endswith("rom_usage_linux.txt"):
                            logFiles[osType]['rom'] = os.path.join(logFolderPath, 'ram_rom', log)
                        elif log.endswith("mem_details_linux.txt"):
                            logFiles[osType]['mem_details_linux'] = os.path.join(logFolderPath, 'ram_rom', log)
                elif perfParam[i] == 'STACK':
                    listDir = os.listdir(os.path.join(logFolderPath, 'ram_rom'))
                    for log in listDir:
                        if log.endswith("stack_usage_linux.txt"):
                            logFiles[osType]['stack'] = os.path.join(logFolderPath, 'ram_rom', log)
                elif perfParam[i] == 'CPU':
                    listDir = os.listdir(os.path.join(logFolderPath, 'cpu'))
                    for log in listDir:
                        if log.endswith("core_cpu_summary.txt"):
                            logFiles[osType]['cpu'] = os.path.join(logFolderPath, 'cpu', log)
                        elif log.endswith("cpu_utilization.txt"):
                            logFiles[osType]['cpu_util'] = os.path.join(logFolderPath, 'cpu', log)
                else:
                    self.loggerInst.warning(f"Invalid perfParam value {perfParam[i]}")
                    print(f"Invalid perfParam value {perfParam[i]}")
                    val = {"FAIL":f"Invalid perfParam value: {perfParam[i]}"}
        if "FAIL" in val:
            return val
        else:
            return logFiles
                    
    def updateConfig(self, configData, logFolder, logFiles):
        """
        Update the configuration data with new log files.

        Args:
        configData (dict): The configuration data.
        logFolder (str): The name of the log folder.
        logFiles (dict): The log files for the log folder.

        Returns:
        dict: The updated configuration data.
        """
        self.loggerInst.info(f"LogProcessor::updateConfig Updating configuration for {logFolder}")
        # Add the log files to the log data dictionary
        if 'logFiles' not in configData:
            configData['logFiles'] = {}
        configData['logFiles'][logFolder] = logFiles

        if 'processedFolders' not in configData:
            configData['processedFolders'] = []
        # Add the log folder to the processed folders list
        if logFolder not in configData['processedFolders']:
            configData['processedFolders'].append(logFolder)
        self.loggerInst.info(f"LogProcessor::updateConfig Updated configuration for {logFolder} successfully")
        return configData

    def saveConfig(self, configData):
        """
        Save the configuration data to the config file.

        Args:
        configData (dict): The configuration data.

        Returns:
        None
        """
        self.loggerInst.info("LogProcessor::saveConfig Saving configuration to config file")
        self.jsonHandler.writeJson(configData)
        self.loggerInst.info("LogProcessor::saveConfig Saved configuration successfully")

    def run(self):
        return self.processLogs()