#!/bin/bash
# Default values
DEFAULT_DURATION=60
DEFAULT_PROCESS="N/A"
DEFAULT_OUTDIR="/tmp"
# Read inputs from environment variables or fallback
duration="${DURATION:-$DEFAULT_DURATION}"
process_name="${MODE:-$DEFAULT_PROCESS}"
output_dir="${OUTDIR:-$DEFAULT_OUTDIR}"
# Ensure output directory exists
mkdir -p "$output_dir"
# File paths
ram_file="$output_dir/ram_usage_linux.txt"
rom_file="$output_dir/rom_usage_linux.txt"
stack_file="$output_dir/stack_usage_linux.txt"
mem_file="$output_dir/mem_details_linux.txt"    
# Initialize log files with headers
if [[ "$process_name" == "N/A" || -z "$process_name" ]]; then
   echo "Timestamp,Process_RAM(MB),System_RAM_Usage(%)" > "$ram_file"
   echo "Timestamp,Process_Stack(MB)" > "$stack_file"
else
   echo "Timestamp,Process_RAM(MB),System_RAM_Usage(%)" > "$ram_file"
   echo "Timestamp,Stack(MB)" > "$stack_file"
fi
echo "Timestamp,Used/Total(MB),Usage(%)" > "$rom_file"
echo "=== Detailed Memory & Storage Snapshot ===" > "$mem_file"   
echo "[INFO] Monitoring for $duration seconds..."
[[ "$process_name" == "N/A" || -z "$process_name" ]] && echo "[INFO] Tracking process: $process_name" || echo "[INFO] Tracking system RAM only"
for ((i=1; i<=duration; i++)); do
   timestamp=$(date +"%T")
   # RAM usage
   total_mem=$(free -m | awk '/Mem:/ {print $2}')
   used_mem=$(free -m | awk '/Mem:/ {print $3}')
   ram_percent=$(awk "BEGIN {printf \"%.2f\", ($used_mem/$total_mem)*100}")
   # Process-specific RAM and stack
   if [[ "$process_name" == "N/A" || -z "$process_name" ]]; then
       pid=$(pgrep -f "$process_name" | head -n 1)
       if [ -n "$pid" ]; then
           proc_mem_kb=$(ps -p "$pid" -o rss=)
           proc_mem_mb=$(awk "BEGIN {printf \"%.2f\", $proc_mem_kb/1024}")
           # Read /proc/PID/status for Stack info
           stack_kb=$(grep -i "VmStk:" /proc/$pid/status | awk '{print $2}')
           stack_mb=$(awk "BEGIN {printf \"%.2f\", $stack_kb/1024}")
       else
           proc_mem_mb="0.00"
           stack_mb="0.00"
       fi
   else
       proc_mem_mb="N/A"
       stack_mb="N/A"
   fi
   # Append data to primary metric files
   if [[ "$process_name" == "N/A" || -z "$process_name" ]]; then
       echo "$timestamp,$proc_mem_mb,$ram_percent" >> "$ram_file"
       echo "$timestamp,$stack_mb" >> "$stack_file"
   else
       echo "$timestamp,$proc_mem_mb,$ram_percent" >> "$ram_file"
       echo "$timestamp,$stack_mb" >> "$stack_file"
   fi
   # ROM usage (disk space)
   rom_data=$(df -m / | awk 'NR==2')
   rom_used_mb=$(echo "$rom_data" | awk '{print $3}')
   rom_total_mb=$(echo "$rom_data" | awk '{print $2}')
   rom_percent=$(echo "$rom_data" | awk '{print $5}')
   echo "$timestamp,${rom_used_mb}MB/${rom_total_mb}MB,$rom_percent" >> "$rom_file"
   {
       echo
       echo "===================== [$timestamp] ====================="
       echo ">>> free -m"
       free -m
       echo
       echo ">>> df -m"
       df -m
       echo
       if [[ "$process_name" == "N/A" || -z "$process_name" ]] && [ -n "$pid" ]; then
           echo ">>> /proc/$pid/status"
           cat /proc/$pid/status
       else
           echo ">>> /proc/meminfo"
           cat /proc/meminfo
       fi
       echo "========================================================"
   } >> "$mem_file"
   sleep 1
done
echo "[INFO] Monitoring complete. Output saved in: $output_dir"