import argparse
import json
import logging
from datetime import datetime
from scapy.all import rdpcap, IP, TCP, UDP
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
import os
import sys


#global variables
EXCEL_CELL_MAX = 32767  # Excel max characters per cell
LOG_FILE = '../../logs/pcap_validator.log'


# -------------------- Logging Setup --------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

# -------------------- Argument Parsing --------------------
def parse_arguments():
    parser = argparse.ArgumentParser(description='PCAP Processor Script')
    parser.add_argument('--app', required=True, help='Application for given PCAP')
    parser.add_argument('--usecase', required=True, help='Use case identifier (e.g., CTXXXX or anything else)')
    parser.add_argument('--pcapPath', required=True, help='Path to the PCAP file')
    parser.add_argument('--resultPath', required=True, help='Path for the parsed/excel/png of pcap result')
    
    return parser.parse_args()

# -------------------- Config Update --------------------
def update_config(config_path, args, processed=False):
    """
    Updates the config JSON so each PCAP (by filename) has its own entry.
    If the current PCAP is already marked processed=True, this function will
    print/log a message and exit the program gracefully (exit code 0).
    """
    try:

        # Load existing config or start fresh
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            if not isinstance(config, dict):
                logging.warning("Config root is not a dict; resetting to {}.")
                config = {}
        except FileNotFoundError:
            config = {}
        except json.JSONDecodeError:
            logging.warning("Config is empty/corrupt; resetting to {}.")
            config = {}

        # ---- One-time migration from old format (if present) ----
        # Old format: {"pcap_files": {"file": "...", "app": "...", "usecase": "...", "processed": ...}}
        if "pcap_files" in config and isinstance(config["pcap_files"], dict):
            old = config.pop("pcap_files")
            old_file = old.get("file")
            if old_file:
                old_key = os.path.basename(old_file)
                config.setdefault(old_key, {
                    "processed": bool(old.get("processed", False)),
                    "app": old.get("app"),
                    "usecase": old.get("usecase"),
                })
                logging.info(f"Migrated old 'pcap_files' entry to key '{old_key}'.")

        # ---- Add/update this run's entry ----
        fname = os.path.basename(args.pcapPath)
        existing = config.get(fname)

        # If already processed, exit here (no changes to main needed)
        if existing and existing.get("processed") is True:
            msg = f"PCAP '{fname}' is already processed. Skipping execution."
            print(msg)
            logging.info(msg)
            sys.exit(0)  # graceful exit, not an error

        # Otherwise, write/update the entry (avoid downgrading; but here we respect the caller's flag)
        config[fname] = {
            "processed": bool(processed),
            "app": args.app,
            "usecase": args.usecase
        }

        # Ensure target directory exists
        os.makedirs(os.path.dirname(config_path) or ".", exist_ok=True)

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        logging.info(f"Config updated for '{fname}'. Processed: {processed}")
    except SystemExit:
        # Re-raise to allow the clean exit to propagate
        raise
    except Exception as e:
        logging.error(f"Failed to update config file: {e}", exc_info=True)
        print(f"Error updating config: {e}")
        # Exit non-zero to signal failure
        sys.exit(1)

# -------------------- Packet Utilities --------------------
def extract_service_and_method_id(packet):
    if packet.haslayer(TCP) and hasattr(packet[TCP], 'payload'):
        payload = bytes(packet[TCP].payload)
        if len(payload) >= 4:
            service_id = int.from_bytes(payload[0:2], byteorder='big')
            method_id = int.from_bytes(payload[2:4], byteorder='big')
            return service_id, method_id
    return None, None

def extract_service_and_method_id_udp(packet):
    if packet.haslayer(UDP) and hasattr(packet[UDP], 'payload'):
        payload = bytes(packet[UDP].payload)
        if len(payload) >= 4:
            service_id = int.from_bytes(payload[0:2], byteorder='big')
            method_id = int.from_bytes(payload[2:4], byteorder='big')
            return service_id, method_id
    return None, None

def decode_payload(packet):
    if packet.haslayer(TCP) and hasattr(packet[TCP], 'payload'):
        return bytes(packet[TCP].payload).hex()
    elif packet.haslayer(UDP) and hasattr(packet[UDP], 'payload'):
        return bytes(packet[UDP].payload).hex()
    return ''

def get_payload_ascii(packet):
    """
    Return an Excel-safe text version of TCP/UDP payload[16:].
    - UTF-8 decode with replacement (never throws)
    - Strip illegal XML characters (prevents IllegalCharacterError)
    - Truncate to Excel cell size limit
    """
    if packet.haslayer(TCP) and hasattr(packet[TCP], 'payload'):
        payload = bytes(packet[TCP].payload)
    elif packet.haslayer(UDP) and hasattr(packet[UDP], 'payload'):
        payload = bytes(packet[UDP].payload)
    else:
        return ''

    if len(payload) >= 16:
        data = payload[16:]
        # Decode as text (never fails)
        text = data.decode('utf-8', errors='replace')

        # Strip characters Excel's XML doesn't allow
        text = ILLEGAL_CHARACTERS_RE.sub('', text)

        # Enforce Excel cell limit (avoid write errors)
        if len(text) > EXCEL_CELL_MAX:
            # leave some room for the truncation note
            keep = EXCEL_CELL_MAX - 20
            over = len(text) - keep
            text = text[:keep] + f"...[truncated {over} chars]"
        return text
    return ''

def get_protocol_name(packet):
    if packet.haslayer(TCP):
        return 'TCP'
    elif packet.haslayer(UDP):
        return 'UDP'
    elif packet.haslayer(IP):
        return 'IP'
    return 'Unknown'

# -------------------- IP Filter Builder --------------------
def build_ip_pair_filter(someip_data):
    filter_ip_pairs = set()
    for app, config_entry in someip_data["applications"].items():
        src_ips = config_entry.get("src_ips", [])
        dst_ips = config_entry.get("dst_ips", [])

        if isinstance(src_ips, str):
            src_ips = [src_ips]
        if isinstance(dst_ips, str):
            dst_ips = [dst_ips]

        for src_ip in src_ips:
            for dst_ip in dst_ips:
                filter_ip_pairs.add((src_ip, dst_ip))
    logging.info(f"Built IP pair filter with {len(filter_ip_pairs)} pairs.")
    return filter_ip_pairs

def turnaround_time(filtered_packets):
    """
    Find the first turnaround time (seconds) between a request and its reverse response
    that match the same service_id and method_id.
    Returns float seconds or None if not found.
    Robust against malformed packets; logs and continues on errors.
    """
    try:
        if not filtered_packets:
            logging.info("turnaround_time: no packets provided.")
            return None
    except Exception as e:
        logging.exception("turnaround_time: error validating input: %s", e)
        return None

    try:
        for i, pkt1 in enumerate(filtered_packets):
            try:
                # Ensure required layers exist
                if not (pkt1.haslayer(IP) and (pkt1.haslayer(TCP) or pkt1.haslayer(UDP))):
                    continue

                src_ip1 = pkt1[IP].src
                dst_ip1 = pkt1[IP].dst

                # Extract IDs safely
                if pkt1.haslayer(TCP):
                    service_id1, method_id1 = extract_service_and_method_id(pkt1)
                elif pkt1.haslayer(UDP):
                    service_id1, method_id1 = extract_service_and_method_id_udp(pkt1)
                else:
                    continue
                
                if service_id1 is None or method_id1 is None:
                    continue

                # Need valid time
                t1_attr = getattr(pkt1, "time", None)
                if t1_attr is None:
                    logging.warning("turnaround_time: pkt1 idx %d has no time attribute", i)
                    continue
                try:
                    t1 = float(t1_attr)
                except Exception as e:
                    logging.warning("turnaround_time: pkt1 idx %d time not numeric: %s", i, e)
                    continue

                # Iterate over subsequent packets only
                for j, pkt2 in enumerate(filtered_packets[i+1:], start=i+1):
                    try:
                        if not (pkt2.haslayer(IP) and (pkt2.haslayer(TCP) or pkt2.haslayer(UDP))):
                            continue

                        src_ip2 = pkt2[IP].src
                        dst_ip2 = pkt2[IP].dst

                        if pkt2.haslayer(TCP):
                            service_id2, method_id2 = extract_service_and_method_id(pkt2)
                        elif pkt2.haslayer(UDP):
                            service_id2, method_id2 = extract_service_and_method_id_udp(pkt2)
                        else:
                            continue
                        
                        if service_id2 is None or method_id2 is None:
                            continue
                        
                        t2_attr = getattr(pkt2, "time", None)
                        if t2_attr is None:
                            logging.warning("turnaround_time: pkt2 idx %d has no time attribute", j)
                            continue
                        try:
                            t2 = float(t2_attr)
                        except Exception as e:
                            logging.warning("turnaround_time: pkt2 idx %d time not numeric: %s", j, e)
                            continue

                        # Match reverse direction + same service & method IDs
                        if (
                            src_ip1 == dst_ip2 and
                            src_ip2 == dst_ip1 and
                            service_id1 == service_id2 and
                            method_id1 == method_id2
                        ):
                            return t2 - t1
                    except Exception as e:
                        logging.warning("turnaround_time: error comparing pkts idx %d and %d: %s", i, j, e)
                        continue
            except Exception as e:
                logging.warning("turnaround_time: error processing pkt1 idx %d: %s", i, e)
                continue
    except Exception as e:
        logging.exception("turnaround_time: unexpected error in outer loop: %s", e)
        return None

    return None

# -------------------- Packet Processing --------------------
def process_packets(packets, app_name, someip_data, filter_ip_pairs, excel_file):
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "PCAP Analysis"

        base_time = packets[0].time

        headers = [
            'No.', 'Time', 'Time (MM.SS.micro)', 'Relevant Time', 'Source IP', 'Destination IP', 'Protocol',
            'Length', 'Service ID', 'Method ID', 'Decoded Config', 'Payload Data'
        ]

        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
        alignment = Alignment(horizontal="center", vertical="center")

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = alignment
            ws.column_dimensions[cell.column_letter].width = 20

        count = 1
        row_num = 2
        filtered_packets = []
        for pkt in packets:
            if pkt.haslayer(IP) and (pkt.haslayer(TCP) or pkt.haslayer(UDP)):
                src_ip = pkt[IP].src
                dst_ip = pkt[IP].dst

                ip_pair = (src_ip, dst_ip)
                reverse_pair = (dst_ip, src_ip)
                ip_match = ip_pair in filter_ip_pairs or reverse_pair in filter_ip_pairs

                if pkt.haslayer(TCP):
                    service_id, method_id = extract_service_and_method_id(pkt)
                    protocol_name = 'TCP'
                elif pkt.haslayer(UDP):
                    service_id, method_id = extract_service_and_method_id_udp(pkt)
                    protocol_name = 'UDP'
                else:
                    continue

                expected_service_id = someip_data["applications"][app_name].get("service_ids", [])
                expected_method_id = someip_data["applications"][app_name].get("method_ids", [])

                if (ip_match and (service_id is not None and f"0x{service_id:04x}" in expected_service_id) and (True or method_id is not None and f"0x{method_id:04x}" in expected_method_id)):
                    dt = datetime.fromtimestamp(float(pkt.time))
                    timestamp = dt.strftime('%Y-%m-%d %H:%M:%S.%f')
                    timestamp_short = f"{dt.minute:02d}.{dt.second:02d}.{dt.microsecond:06d}"
                    time_rel = pkt.time - base_time
                    length = len(pkt)
                    decoded_config = decode_payload(pkt)
                    payload_ascii = get_payload_ascii(pkt)
                    row_data = [
                        count, timestamp, timestamp_short, f"{time_rel:.6f}", src_ip, dst_ip, protocol_name,
                        length,
                        f"0x{service_id:04x}" if service_id is not None else '',
                        f"0x{method_id:04x}" if method_id is not None else '',
                        decoded_config, payload_ascii
                    ]
                    filtered_packets.append(pkt)
                    for col_num, value in enumerate(row_data, 1):
                        ws.cell(row=row_num, column=col_num, value=value)
                    row_num += 1
                    count += 1

        # ---- Compute and write Turnaround Time (TAT) in columns N & O ----
        TAT = turnaround_time(filtered_packets)

        # Header cells for TAT
        ws["N1"] = "Turnaround Time (s)"
        ws["O1"] = "Turnaround Time (ms)"

        # Reuse your header styling for consistency
        for cell_addr in ("N1", "O1"):
            c = ws[cell_addr]
            c.font = header_font
            c.fill = header_fill
            c.alignment = alignment

        # Make the TAT columns wider
        ws.column_dimensions['N'].width = 24
        ws.column_dimensions['O'].width = 22

        # Value cell styling: bold + colored fill
        tat_value_font = Font(bold=True, color="000000")  # black bold
        tat_value_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")  # light green
        tat_value_align = Alignment(horizontal="center", vertical="center")

        if TAT is not None:
            ws["N2"] = round(TAT, 6)           # seconds
            ws["O2"] = round(TAT * 1000, 3)    # milliseconds
            ws["N2"].number_format = "0.000000"
            ws["O2"].number_format = "0.000"
        else:
            ws["N2"] = "N/A"
            ws["O2"] = "N/A"

        for cell_addr in ("N2", "O2"):
            c = ws[cell_addr]
            c.font = tat_value_font
            c.fill = tat_value_fill
            c.alignment = tat_value_align

        wb.save(excel_file)
        logging.info(f"Processed {count - 1} matching packets. Excel saved to {excel_file}.") 
        return {
            "TestRawPath": excel_file,
            "Error": None
        }
    except Exception as e:
        logging.error(f"Error while processing packets: {e}")
        return {
            "TestRawPath": None,
            "Error": str(e)
        }

# -------------------- Main Function --------------------
def main():
    try:
        args = parse_arguments()
        config_path = '../../configs/pcapConfig.json'
        excel_file = os.path.join(args.resultPath, f"{args.app}_tcp_dump_analysis.xlsx")

        logging.info("Script started.")
        update_config(config_path, args, processed=False)

        try:
            packets = rdpcap(args.pcapPath)
            logging.info(f"Loaded {len(packets)} packets from {args.pcapPath}")
        except Exception as e:
            logging.error(f"Failed to read PCAP file: {e}")
            return {
            "TestRawPath": None,
            "Error": str(e)
            }

        try:
            with open("../../configs/someIPApplicationFilterConfig.json", 'r') as file:
                someip_data = json.load(file)
        except Exception as e:
            logging.error(f"Failed to load SOME/IP config: {e}")
            return {
            "TestRawPath": None,
            "Error": str(e)
            }

        filter_ip_pairs = build_ip_pair_filter(someip_data)
        result = process_packets(packets, args.app, someip_data, filter_ip_pairs, excel_file)
    
        if result["Error"]:
            return result
        
        update_config(config_path, args, processed=True)
        logging.info("Script completed successfully.")
        print("Filtered packets and data have been saved to Excel.")
        return result
    
    except Exception as e:
        logging.critical(f"[PROCESSING] Fatal error during execution: {e}", exc_info=True)
        print(f"[FATAL] Error during processing: {e}")
        return {
            "TestRawPath": None,
            "Error": str(e)
        }

# -------------------- Entry Point --------------------
if __name__ == "__main__":
    result = main()
    
    print(json.dumps(result))