# Sys4Sys5-CanoePython_AutomationFramework

EthernetTesting -  CANoe config file
-------------------------------------
- Launch the cfg file with Vector CANoe version 16 or above
- Simulate the cfg file and use the 'TC_Execution_by_AppName' panel to either run the testcases based on application name or based on Tetscase ID.

CAPL
----
- Includes/ - contains include cin files
- Nodes/ - contains the CAPL script for all the ECU Nodes (IVI, PADAS, TEL, ELITE and CA55_ASILB) created in Ethernet channel
- TestModules/ - contains the CAPL script for all the test cases in the test modules based on application names

configs
--------
- contains all the config files used by Python scripts for setting DLT log filters, ECU related configurations for SSH/SFTP and PCAP filters
- based on the values read from the config files, Python scripts will run the scripts in ECU

shell_scripts
--------------
- contains shell scripts for CPU, RAM, ROM and Stack utilization captures from ECU

src
---
- contains Python scripts for log capturing, parsing, report generation, etc..

Outcomes of the PoC
-------------------
- logs/ - conatins logs to debug the Python script if anything failed from Python
- results/ - contains the Resource utilization logs captured frrom ECU, PCAP files and DLT files captured from ECU
- Workbook_Graph_Report/ - contains the workbooks which have consolidated data and graphs for all the testcases executed
