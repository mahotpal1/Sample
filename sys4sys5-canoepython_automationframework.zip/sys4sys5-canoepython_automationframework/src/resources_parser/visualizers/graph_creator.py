import matplotlib.pyplot as plt
import numpy as np
import os

class GraphCreator:
    def __init__(self, logger, reportDir, folder, consumptionData):
        self.logger = logger
        self.reportDir = reportDir
        self.folder = folder
        self.consumptionData = consumptionData

    def plotCpuCoreUtilization(self, topDetails, threshold):
        """
        Plots CPU core utilization over time.
        Args:
            topDetails (dict): {timestamp: [cpu_dict, top_cpu]}
            threshold (float): CPU utilization threshold to show on the graph.
        """
        try:
            if not topDetails:
                self.logger.error("CPUUsageParser::plotCpuCoreUtilization - topDetails is empty")
                raise ValueError("topDetails dictionary is empty")
            core_data = {}
            top_consumption = {}
            for timestamp, entry in topDetails.items():
                try:
                    cpu_dict, top_cpu = entry
                except (ValueError, TypeError) as e:
                    self.logger.warning(f"Skipping invalid entry at timestamp {timestamp}: {entry}, error: {e}")
                    continue
                # Store per-core values
                for core, value in cpu_dict.items():
                    try:
                        core_data.setdefault(core, {})[timestamp] = round(float(value), 2)
                    except (ValueError, TypeError) as e:
                        self.logger.warning(f"Invalid CPU value for core {core} at {timestamp}: {value}, error: {e}")
                # Store top CPU consumption
                try:
                    top_consumption[timestamp] = round(float(top_cpu), 2)
                except (ValueError, TypeError) as e:
                    self.logger.warning(f"Invalid top CPU value at {timestamp}: {top_cpu}, error: {e}")
            # Plot cores and topConsumption
            fig, ax1 = plt.subplots(figsize=(14,6))
            for core, values in core_data.items():
                iterations = sorted(values.keys())
                vals = [values[i] for i in iterations]
                ax1.plot(iterations, vals, marker='o', label=core)
            # Threshold line
            ax1.axhline(y=threshold, color='red', linestyle='--', label=f'Threshold ({threshold}%)')
            ax1.set_xlabel("Time Stamp")
            ax1.set_ylabel("CPU Utilization (%)")
            ax1.grid(True)
            fig.suptitle("Core-wise CPU Utilization vs Time Stamp")
            fig.legend(loc="upper right", bbox_to_anchor=(1.01, 1.0))
            plt.xticks(rotation=90)
            plt.tight_layout(rect=[0, 0, 0.89, 1])
            save_path = os.path.join(self.reportDir, self.folder, 'cpu_core_wise_graph.png')
            plt.savefig(save_path)
            plt.close(fig)
            self.logger.info(f"CPU core utilization graph saved at {save_path}")
        except Exception as e:
            self.logger.error(f"CPUUsageParser::plotCpuCoreUtilization - An error occurred: {str(e)}")
            raise

    def plotRamGraph(self, topDetails):
        # plot data
        times = topDetails.keys()
        usages = sorted([topDetails[t][1] for t in times])
        fig, ax1 = plt.subplots(figsize=(10, 6))
        ax1.set_xlabel("Time stamp", rotation=0, labelpad=15, va='center')
        ax1.plot(times, usages, marker='o', linestyle='-', label = 'Usage (%)')
        # Threshold
        #ax1.axhline(y=threshold, color='red', linestyle='--', label=f'Threshold ({threshold}%)')
        ax1.set_ylabel("RAM Utilization%", rotation=90, labelpad=40, va='center')
        ax1.set_title("Ram Utilization(%) vs Time Stamp")
        ax1.legend()
        ax1.grid(True)
        plt.xticks(rotation=90)
        plt.tight_layout()
        plt.savefig(os.path.join(self.reportDir, self.folder, 'ram_util.png'))  

    def plotRomGraph(self, topDetails):
        # plot data
        times = topDetails.keys()
        usages = sorted([topDetails[t] for t in times])
        fig, ax1 = plt.subplots(figsize=(10, 6))
        ax1.set_xlabel("Time stamp", rotation=0, labelpad=15, va='center')
        ax1.plot(times, usages, marker='o', linestyle='-', label = 'Usage (%)')
        # Threshold
        #ax1.axhline(y=threshold, color='red', linestyle='--', label=f'Threshold ({threshold}%)')
        ax1.set_ylabel("ROM Utilization%", rotation=90, labelpad=40, va='center')
        ax1.set_title("Rom Utilization(%) vs Time Stamp")
        ax1.legend()
        ax1.grid(True)
        plt.xticks(rotation=90)
        plt.tight_layout()
        plt.savefig(os.path.join(self.reportDir, self.folder, 'rom_util.png'))        

    def generateGraph(self):
        for os, specs in self.consumptionData.items():
            if os.lower() == 'linux':
                for spec, details in specs[0].items():
                    if spec == 'cpu':
                        self.plotCpuCoreUtilization(details[1], details[3])
                    elif spec == 'ram':
                        self.plotRamGraph(details[1])
                    elif spec == 'rom':
                        self.plotRomGraph(details[1])
            elif os.lower() == 'qnx':
                pass

    def run(self):
        self.generateGraph()