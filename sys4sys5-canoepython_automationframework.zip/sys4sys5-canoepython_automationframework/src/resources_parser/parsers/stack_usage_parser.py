import re
from datetime import date
import threading 
import time

class STACKUsageParser:
    """
        This class takes in STACK usage data, extracts and processes the relevant details
    """

    def __init__(self, logger):
        self.logger = logger
        self.logger.info("STACKUsageParser instance created.")

    def processLinuxStackUtilization(self, stackDetails):
        """
        Processes the Stack details for report and graph generation.

        Args:
        stackDetails (dict): A dictionary containing the stack utilization details.

        Returns:
        dict: A dictionary containing the average, maximum, and minimum utilization.
        """
        try:
            self.logger.info("STACKUsageParser::processLinuxStackUtilization Processing results...")
            # Handle cases if dictionary is empty
            if not stackDetails:
                self.logger.error("STACKUsageParser::processLinuxStackUtilization topDetails is empty")
                return {}

            # Extract utilization values and convert to floats
            utilizations = [float(value) for value in stackDetails.values()]

            # Calculate min, max, and average
            results = {
                'min': min(utilizations),
                'max': max(utilizations),
                'avg': sum(utilizations) / len(utilizations)
            }

            return results
        except Exception as e:
            print(f"STACKUsageParser::processLinuxStackUtilization An error occurred: {str(e)}")
            self.logger.error(f"STACKUsageParser::processLinuxStackUtilization An error occurred: {str(e)}")
            raise

    def linuxLogExtractor(self, logFile):
        """
            Fetches STACK utilization data from a log file.

            Args:
            logFile (str): The path to the log file containing Stack utilization data.

            Returns:
            dict: A dictionary containing the STACK utilization details.

            Note:
            This function uses regular expressions to parse the log file and extract the STACK utilization data.
        """
        self.logger.info(f"STACKUsageParser::linuxLogExtractor Attempting to extract STACK utilization data from log file: {logFile}")
        logPattern1 = r"^(\d{2}:\d{2}:\d{2}),([0-9\.]+)$"
        try:
            with open(logFile, 'r') as file:
                # initialize an empty dictionary to store stack details
                stackDetails = {}
                # stores stack details for each interval
                _currentItr = 0
                self.logger.info("STACKUsageParser::linuxLogExtractor Log file opened successfully.")
                for line in file:
                    if (matchStackPattern := re.match(logPattern1, line)):
                        stackDetails[_currentItr] = matchStackPattern.group(2)
                        _currentItr += 1
                if not stackDetails:
                    self.logger.error("STACKUsageParser::linuxLogExtractor Stack details are empty")
                    raise ValueError("Stack details are empty")
                return stackDetails
        except FileNotFoundError:
            self.logger.error(f"STACKUsageParser::linuxLogExtractor Error: File '{logFile}' not found.")
        except PermissionError:
            self.logger.error(f"STACKUsageParser::linuxLogExtractor Error: Permission denied to read file '{logFile}'.")
        except OSError as e:
            self.logger.error(f"STACKUsageParser::linuxLogExtractor Error: An OS error occurred while reading file '{logFile}': {e}")
        except Exception as e:
            self.logger.error(f"STACKUsageParser::linuxLogExtractor An unexpected error occurred: {e}")

    def run(self, osType, logFile, readConfig):
        print(f"Parsing {logFile}")
        if osType=='linux':
            topDetails = self.linuxLogExtractor(logFile)
            sets = self.processLinuxStackUtilization(topDetails)
            return [sets, topDetails]
        elif osType=='qnx':
            self.logger.info(f"STACKUsageParser::run Processing QNX STACK usage details")
            pass